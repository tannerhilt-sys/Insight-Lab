// prisma/seed.js
// Run: node src/prisma/seed.js
// Seeds the database with a demo user for local development
"use strict";

require("dotenv").config();
const bcrypt = require("bcrypt");
const { db } = require("../lib/db");

async function main() {
  console.log("🌱 Seeding Finance Buddy database...");

  // ── Demo user ──────────────────────────────────────────────────
  const passwordHash = await bcrypt.hash("password123", 12);
  const user = await db.user.upsert({
    where:  { email: "demo@financebuddy.dev" },
    update: {},
    create: { email: "demo@financebuddy.dev", passwordHash, ageConfirmed: true },
  });
  console.log("  ✅ Demo user:    demo@financebuddy.dev / password123");

  // ── Demo profile ───────────────────────────────────────────────
  await db.userProfile.upsert({
    where:  { userId: user.id },
    update: {},
    create: {
      userId:            user.id,
      buddyName:         "Finn",
      goals:             ["save_emergency_fund", "start_investing"],
      knowledgeLevel:    "BEGINNER",
      riskScore:         2,
      savingsHabit:      "OCCASIONAL",
      investingInterest: true,
      profileSummary:    "You're off to a great start! With a conservative approach and goals around saving and investing, Finn will help guide you every step of the way. Focus on building your emergency fund first, then we'll explore beginner-friendly investing options together.",
    },
  });
  console.log("  ✅ Demo profile: Buddy name 'Finn', risk score 2/5");

  // ── Demo budget entries ────────────────────────────────────────
  const thisMonth = new Date().toISOString().slice(0, 7);
  const entries = [
    { type: "INCOME",  amount: 3200, category: "OTHER",         description: "Monthly salary",      date: `${thisMonth}-01` },
    { type: "EXPENSE", amount: 1100, category: "HOUSING",       description: "Rent",                date: `${thisMonth}-02` },
    { type: "EXPENSE", amount: 280,  category: "FOOD",          description: "Groceries",           date: `${thisMonth}-05` },
    { type: "EXPENSE", amount: 120,  category: "FOOD",          description: "Restaurants",         date: `${thisMonth}-10` },
    { type: "EXPENSE", amount: 85,   category: "TRANSPORT",     description: "Gas",                 date: `${thisMonth}-08` },
    { type: "EXPENSE", amount: 60,   category: "TRANSPORT",     description: "Public transit pass", date: `${thisMonth}-01` },
    { type: "EXPENSE", amount: 180,  category: "ENTERTAINMENT", description: "Subscriptions + fun", date: `${thisMonth}-12` },
    { type: "EXPENSE", amount: 200,  category: "SAVINGS",       description: "Emergency fund transfer", date: `${thisMonth}-01` },
  ];

  for (const e of entries) {
    await db.budgetEntry.create({
      data: { userId: user.id, ...e, amount: e.amount, date: new Date(e.date) },
    });
  }
  console.log("  ✅ Demo budget:  8 entries for " + thisMonth);

  // ── Demo savings goal ─────────────────────────────────────────
  await db.savingsGoal.create({
    data: {
      userId:        user.id,
      label:         "Emergency Fund",
      targetAmount:  5000,
      currentAmount: 1200,
      deadline:      new Date(new Date().getFullYear() + 1, 0, 1),
    },
  });
  console.log("  ✅ Demo goal:    Emergency Fund ($1,200 / $5,000)");

  // ── Demo holdings ─────────────────────────────────────────────
  await db.holding.createMany({
    data: [
      { userId: user.id, ticker: "VTI",  companyName: "Vanguard Total Stock Market ETF", shares: 3,  avgCost: 238.50 },
      { userId: user.id, ticker: "AAPL", companyName: "Apple Inc.",                       shares: 5,  avgCost: 210.00 },
    ],
  });
  console.log("  ✅ Demo portfolio: VTI x3, AAPL x5");

  // ── Demo insight card ─────────────────────────────────────────
  await db.insightCard.create({
    data: {
      userId:      user.id,
      type:        "RECOMMENDATION",
      title:       "Consider adding a bond ETF for stability",
      body:        "With a conservative risk score of 2/5 and a goal of building an emergency fund, adding a bond ETF like BND could reduce your portfolio's volatility. Bonds tend to move differently than stocks, which helps smooth out the bumps.",
      riskLabel:   "LOW",
      actionLabel: "Learn About BND",
      status:      "PENDING",
    },
  });
  console.log("  ✅ Demo insight: 1 pending recommendation card");

  console.log("\n🎉 Seed complete! Log in at http://localhost:5173 with demo@financebuddy.dev");
}

main()
  .catch(err => { console.error("❌ Seed failed:", err); process.exit(1); })
  .finally(() => db.$disconnect());
