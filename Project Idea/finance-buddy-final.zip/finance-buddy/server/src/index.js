// Finance Buddy — Express Server Entry Point
"use strict";

require("dotenv").config();
const express = require("express");
const cors    = require("cors");

const { validateEnv } = require("./lib/validateEnv");
validateEnv();

const authRoutes      = require("./routes/auth");
const onboardRoutes   = require("./routes/onboarding");
const budgetRoutes    = require("./routes/budget");
const portfolioRoutes = require("./routes/portfolio");
const chatRoutes      = require("./routes/chat");
const insightRoutes   = require("./routes/insights");
const marketRoutes    = require("./routes/market");

const { errorHandler } = require("./middleware/errorHandler");
const { authenticate }  = require("./middleware/authenticate");

const app  = express();
const PORT = process.env.PORT || 3001;

// ── Middleware ──────────────────────────────────────────────
app.use(cors({ origin: process.env.CLIENT_ORIGIN || "http://localhost:5173", credentials: true }));
app.use(express.json());

// ── Health check (public) ───────────────────────────────────
app.get("/health", (req, res) => {
  res.json({
    status:    "ok",
    service:   "finance-buddy-api",
    version:   "1.0.0",
    timestamp: new Date().toISOString(),
  });
});

// ── Public routes ───────────────────────────────────────────
app.use("/api/v1/auth", authRoutes);

// ── Protected routes (require valid JWT) ────────────────────
app.use("/api/v1/onboarding", authenticate, onboardRoutes);
app.use("/api/v1/budget",     authenticate, budgetRoutes);
app.use("/api/v1/portfolio",  authenticate, portfolioRoutes);
app.use("/api/v1/chat",       authenticate, chatRoutes);
app.use("/api/v1/insights",   authenticate, insightRoutes);
app.use("/api/v1/market",     authenticate, marketRoutes);

// ── 404 handler ─────────────────────────────────────────────
app.use((req, res) => {
  res.status(404).json({ error: "Route not found", path: req.path });
});

// ── Global error handler ────────────────────────────────────
app.use(errorHandler);

// ── Start ───────────────────────────────────────────────────
if (require.main === module) {
  app.listen(PORT, () => {
    console.log("✅ Finance Buddy API running on http://localhost:" + PORT);
    console.log("   Health check: http://localhost:" + PORT + "/health");
    console.log("   Environment:  " + (process.env.NODE_ENV || "development"));
  });
}

module.exports = app;
