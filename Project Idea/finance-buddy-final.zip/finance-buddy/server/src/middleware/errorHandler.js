// middleware/errorHandler.js
"use strict";

function errorHandler(err, req, res, next) {
  console.error("[ERROR]", err.message);

  // Prisma known errors
  if (err.code === "P2002") {
    return res.status(409).json({ error: "A record with that value already exists" });
  }
  if (err.code === "P2025") {
    return res.status(404).json({ error: "Record not found" });
  }

  const status = err.status || err.statusCode || 500;
  res.status(status).json({
    error: status === 500 ? "Internal server error" : err.message,
  });
}

module.exports = { errorHandler };
