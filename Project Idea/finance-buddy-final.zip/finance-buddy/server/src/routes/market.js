// routes/market.js
"use strict";

const express = require("express");
const { getQuote, searchTickers, getCompanyOverview, getNews } = require("../lib/market");
const { claudeChat } = require("../lib/claude");

const router = express.Router();

// GET /api/v1/market/quote/:ticker
router.get("/quote/:ticker", async (req, res, next) => {
  try {
    const quote = await getQuote(req.params.ticker.toUpperCase());
    res.json(quote);
  } catch (err) { next(err); }
});

// GET /api/v1/market/search?q=apple
router.get("/search", async (req, res, next) => {
  try {
    if (!req.query.q) return res.status(400).json({ error: "q query parameter is required" });
    const results = await searchTickers(req.query.q);
    res.json({ results });
  } catch (err) { next(err); }
});

// GET /api/v1/market/news?ticker=AAPL
router.get("/news", async (req, res, next) => {
  try {
    if (!req.query.ticker) return res.status(400).json({ error: "ticker query parameter is required" });

    const articles = await getNews(req.query.ticker.toUpperCase());

    // Translate top headline into plain language via Claude
    let translation = null;
    if (articles.length > 0) {
      const systemPrompt = `You are Finance Buddy. Translate this financial news headline into
2 sentences a 16-year-old beginner would understand. Explain (1) what happened and
(2) why it might matter to a beginner investor. Be concise and jargon-free.`;

      translation = await claudeChat({
        systemPrompt,
        userMessage: `Headline: "${articles[0].title}"\nSummary: ${articles[0].summary?.slice(0, 200) || ""}`,
        maxTokens: 200,
        temperature: 0.6,
      });
    }

    res.json({ articles, translation });
  } catch (err) { next(err); }
});

module.exports = router;
