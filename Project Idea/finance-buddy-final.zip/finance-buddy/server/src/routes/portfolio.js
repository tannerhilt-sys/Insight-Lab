// routes/portfolio.js
"use strict";

const express        = require("express");
const { db }         = require("../lib/db");
const { claudeChat } = require("../lib/claude");
const { getQuote, getCompanyOverview } = require("../lib/market");

const router = express.Router();

// ── Helper: enrich holdings with live prices ─────────────────────
async function enrichHoldings(holdings) {
  return Promise.all(holdings.map(async h => {
    try {
      const quote = await getQuote(h.ticker);
      const currentValue = quote.price * Number(h.shares);
      const costBasis    = Number(h.avgCost) * Number(h.shares);
      return {
        ...h,
        currentPrice:  quote.price,
        change:        quote.change,
        changePercent: quote.changePercent,
        currentValue,
        gainLoss:      currentValue - costBasis,
        gainLossPercent: ((currentValue - costBasis) / costBasis * 100).toFixed(2),
        stale: false,
      };
    } catch {
      // Market data unavailable — return last known data with stale flag
      return { ...h, currentPrice: Number(h.avgCost), stale: true };
    }
  }));
}

// GET /api/v1/portfolio/holdings
router.get("/holdings", async (req, res, next) => {
  try {
    const holdings  = await db.holding.findMany({ where: { userId: req.userId } });
    const enriched  = await enrichHoldings(holdings);
    const totalValue    = enriched.reduce((s, h) => s + (h.currentValue || 0), 0);
    const totalGainLoss = enriched.reduce((s, h) => s + (h.gainLoss || 0), 0);
    res.json({ holdings: enriched, totalValue, totalGainLoss });
  } catch (err) { next(err); }
});

// POST /api/v1/portfolio/buy  — paper trade
router.post("/buy", async (req, res, next) => {
  try {
    const { ticker, shares } = req.body;
    if (!ticker || !shares || shares <= 0) return res.status(400).json({ error: "ticker and shares (> 0) are required" });

    const quote = await getQuote(ticker.toUpperCase());
    const company = await getCompanyOverview(ticker.toUpperCase()).catch(() => ({ name: ticker.toUpperCase() }));

    // Upsert: if holding exists, average down the cost
    const existing = await db.holding.findUnique({
      where: { userId_ticker: { userId: req.userId, ticker: ticker.toUpperCase() } },
    });

    let holding;
    if (existing) {
      const totalShares = Number(existing.shares) + Number(shares);
      const newAvgCost  = ((Number(existing.avgCost) * Number(existing.shares)) + (quote.price * Number(shares))) / totalShares;
      holding = await db.holding.update({
        where: { userId_ticker: { userId: req.userId, ticker: ticker.toUpperCase() } },
        data:  { shares: totalShares, avgCost: newAvgCost },
      });
    } else {
      holding = await db.holding.create({
        data: {
          userId:      req.userId,
          ticker:      ticker.toUpperCase(),
          companyName: company.name || ticker.toUpperCase(),
          shares:      Number(shares),
          avgCost:     quote.price,
        },
      });
    }
    res.status(201).json({ holding, executedPrice: quote.price });
  } catch (err) { next(err); }
});

// POST /api/v1/portfolio/sell  — paper trade
router.post("/sell", async (req, res, next) => {
  try {
    const { ticker, shares } = req.body;
    if (!ticker || !shares || shares <= 0) return res.status(400).json({ error: "ticker and shares (> 0) are required" });

    const existing = await db.holding.findUnique({
      where: { userId_ticker: { userId: req.userId, ticker: ticker.toUpperCase() } },
    });
    if (!existing) return res.status(404).json({ error: "You do not hold any shares of " + ticker });
    if (Number(existing.shares) < Number(shares)) return res.status(400).json({ error: "Insufficient shares to sell" });

    const quote = await getQuote(ticker.toUpperCase());
    const newShares = Number(existing.shares) - Number(shares);

    let holding;
    if (newShares === 0) {
      await db.holding.delete({ where: { userId_ticker: { userId: req.userId, ticker: ticker.toUpperCase() } } });
      holding = null;
    } else {
      holding = await db.holding.update({
        where: { userId_ticker: { userId: req.userId, ticker: ticker.toUpperCase() } },
        data:  { shares: newShares },
      });
    }
    res.json({ holding, executedPrice: quote.price, sharesRemaining: newShares });
  } catch (err) { next(err); }
});

// GET /api/v1/portfolio/watchlist
router.get("/watchlist", async (req, res, next) => {
  try {
    // Watchlist is stored as holdings with 0 shares
    const watchlist = await db.holding.findMany({
      where: { userId: req.userId, shares: 0 },
    });
    const enriched = await enrichHoldings(watchlist);
    res.json({ watchlist: enriched });
  } catch (err) { next(err); }
});

// POST /api/v1/portfolio/watchlist
router.post("/watchlist", async (req, res, next) => {
  try {
    const { ticker } = req.body;
    if (!ticker) return res.status(400).json({ error: "ticker is required" });

    const company = await getCompanyOverview(ticker.toUpperCase()).catch(() => ({ name: ticker.toUpperCase() }));
    const item = await db.holding.upsert({
      where:  { userId_ticker: { userId: req.userId, ticker: ticker.toUpperCase() } },
      update: {},
      create: { userId: req.userId, ticker: ticker.toUpperCase(), companyName: company.name, shares: 0, avgCost: 0 },
    });
    res.status(201).json({ item });
  } catch (err) { next(err); }
});

// DELETE /api/v1/portfolio/watchlist/:ticker
router.delete("/watchlist/:ticker", async (req, res, next) => {
  try {
    await db.holding.deleteMany({
      where: { userId: req.userId, ticker: req.params.ticker.toUpperCase(), shares: 0 },
    });
    res.status(204).send();
  } catch (err) { next(err); }
});

// GET /api/v1/portfolio/explain/:ticker  — Claude stock explanation
router.get("/explain/:ticker", async (req, res, next) => {
  try {
    const ticker  = req.params.ticker.toUpperCase();
    const profile = await db.userProfile.findUnique({ where: { userId: req.userId } });
    const [quote, company] = await Promise.all([
      getQuote(ticker),
      getCompanyOverview(ticker),
    ]);

    const systemPrompt = `You are Finance Buddy. Explain this stock to a beginner investor in exactly
3 short paragraphs: (1) what the company does, (2) what drives its stock price, (3) one thing
a beginner with a risk score of ${profile?.riskScore || 2}/5 should watch out for. No jargon.`;

    const userMessage = `Explain ${ticker} (${company.name}).
Current price: $${quote.price}
52-week range: $${company.week52Low} – $${company.week52High}
Sector: ${company.sector}
Description: ${company.description?.slice(0, 300)}`;

    const explanation = await claudeChat({ systemPrompt, userMessage, maxTokens: 500, temperature: 0.6 });
    res.json({ ticker, explanation, quote });
  } catch (err) { next(err); }
});

module.exports = router;
