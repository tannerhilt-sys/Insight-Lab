// routes/insights.js
"use strict";

const express        = require("express");
const { db }         = require("../lib/db");
const { claudeChat } = require("../lib/claude");

const router = express.Router();

// GET /api/v1/insights
router.get("/", async (req, res, next) => {
  try {
    const cards = await db.insightCard.findMany({
      where:   { userId: req.userId },
      orderBy: { createdAt: "desc" },
      take:    20,
    });
    res.json({ cards });
  } catch (err) { next(err); }
});

// POST /api/v1/insights/generate  — trigger AI generation
router.post("/generate", async (req, res, next) => {
  try {
    const profile  = await db.userProfile.findUnique({ where: { userId: req.userId } });
    const holdings = await db.holding.findMany({ where: { userId: req.userId, shares: { gt: 0 } } });

    if (!profile) return res.status(400).json({ error: "Complete onboarding before generating insights" });

    const systemPrompt = `You are Finance Buddy. Generate a personalized investment or savings
recommendation for this beginner user. Return ONLY valid JSON in this exact shape:
{
  "title": "short headline (max 10 words)",
  "body": "2-3 sentence plain-language explanation",
  "riskLabel": "LOW" | "MEDIUM" | "HIGH",
  "actionLabel": "short CTA button text (max 4 words)"
}
No markdown, no preamble, just the JSON object.`;

    const userMessage = `User profile:
- Risk score: ${profile.riskScore}/5
- Goals: ${profile.goals.join(", ")}
- Knowledge level: ${profile.knowledgeLevel}
- Current holdings: ${holdings.length > 0 ? holdings.map(h => h.ticker).join(", ") : "none yet"}`;

    const raw = await claudeChat({ systemPrompt, userMessage, maxTokens: 400, temperature: 0.7 });

    let parsed;
    try {
      parsed = JSON.parse(raw.replace(/```json|```/g, "").trim());
    } catch {
      return res.status(500).json({ error: "AI returned unexpected format — please try again" });
    }

    const card = await db.insightCard.create({
      data: {
        userId:      req.userId,
        type:        "RECOMMENDATION",
        title:       parsed.title,
        body:        parsed.body,
        riskLabel:   parsed.riskLabel || "MEDIUM",
        actionLabel: parsed.actionLabel || "Learn More",
        status:      "PENDING",
      },
    });

    res.status(202).json({ card });
  } catch (err) { next(err); }
});

// POST /api/v1/insights/:id/accept
router.post("/:id/accept", async (req, res, next) => {
  try {
    const card = await db.insightCard.findUnique({ where: { id: req.params.id } });
    if (!card || card.userId !== req.userId) return res.status(404).json({ error: "Insight not found" });

    const updated = await db.insightCard.update({
      where: { id: req.params.id },
      data:  { status: "ACCEPTED" },
    });
    res.json({ card: updated });
  } catch (err) { next(err); }
});

// POST /api/v1/insights/:id/dismiss
router.post("/:id/dismiss", async (req, res, next) => {
  try {
    const card = await db.insightCard.findUnique({ where: { id: req.params.id } });
    if (!card || card.userId !== req.userId) return res.status(404).json({ error: "Insight not found" });

    const updated = await db.insightCard.update({
      where: { id: req.params.id },
      data:  { status: "DISMISSED" },
    });
    res.json({ card: updated });
  } catch (err) { next(err); }
});

module.exports = router;
