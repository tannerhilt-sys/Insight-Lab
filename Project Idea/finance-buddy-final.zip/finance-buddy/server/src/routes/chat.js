// routes/chat.js
"use strict";

const express                       = require("express");
const { db }                        = require("../lib/db");
const { claudeStream, claudeChat, buildUserContext } = require("../lib/claude");

const router = express.Router();

// ── Helper: load user context for system prompt ───────────────────
async function loadContext(userId) {
  const profile  = await db.userProfile.findUnique({ where: { userId } });
  const holdings = await db.holding.findMany({ where: { userId, shares: { gt: 0 } } });

  // Simple budget health for current month
  const month   = new Date().toISOString().slice(0, 7);
  const start   = new Date(`${month}-01`);
  const end     = new Date(start.getFullYear(), start.getMonth() + 1, 0);
  const entries = await db.budgetEntry.findMany({ where: { userId, date: { gte: start, lte: end } } });
  const income   = entries.filter(e => e.type === "INCOME").reduce((s, e) => s + Number(e.amount), 0);
  const expenses = entries.filter(e => e.type === "EXPENSE").reduce((s, e) => s + Number(e.amount), 0);
  const healthScore = income > 0 ? Math.min(100, Math.round((1 - expenses / income) * 125)) : null;

  return { profile, holdings, budgetSummary: healthScore !== null ? { healthScore } : null };
}

// POST /api/v1/chat/message  — streaming SSE response
router.post("/message", async (req, res, next) => {
  try {
    const { message, history = [] } = req.body;
    if (!message) return res.status(400).json({ error: "message is required" });

    const { profile, holdings, budgetSummary } = await loadContext(req.userId);

    const systemPrompt = profile
      ? `You are ${profile.buddyName}, the user's personal Finance Buddy companion.
${buildUserContext(profile, budgetSummary, holdings)}
Be warm, patient, and educational. Always explain financial terms in plain language.
Never execute actions — suggest and explain only. Keep responses concise (3-5 sentences unless more detail is asked for).`
      : `You are Finance Buddy, a friendly AI financial companion for beginners.
Be warm, patient, and educational. Explain all financial terms simply.`;

    // Build messages array: history + new message
    const messages = [
      ...history.map(m => ({ role: m.role, content: m.content })),
      { role: "user", content: message },
    ];

    await claudeStream({ systemPrompt, messages, res });
  } catch (err) { next(err); }
});

// GET /api/v1/chat/suggestions  — context-aware quick prompts
router.get("/suggestions", async (req, res, next) => {
  try {
    const { profile, holdings, budgetSummary } = await loadContext(req.userId);

    const hasPortfolio = holdings.length > 0;
    const hasBudget    = budgetSummary !== null;

    const systemPrompt = `You are Finance Buddy. Generate exactly 4 short, friendly quick-prompt
suggestions a beginner user might want to ask their financial companion right now.
Return ONLY a JSON array of 4 strings. No explanation, no markdown, no preamble.`;

    const userMessage = `User context:
- Knowledge level: ${profile?.knowledgeLevel || "BEGINNER"}
- Has portfolio: ${hasPortfolio} ${hasPortfolio ? "(holds: " + holdings.map(h => h.ticker).join(", ") + ")" : ""}
- Has budget data: ${hasBudget} ${hasBudget ? "(health: " + budgetSummary.healthScore + "/100)" : ""}
- Goals: ${profile?.goals?.join(", ") || "not set yet"}`;

    const raw = await claudeChat({ systemPrompt, userMessage, maxTokens: 200, temperature: 0.8 });

    let suggestions;
    try {
      suggestions = JSON.parse(raw.replace(/```json|```/g, "").trim());
    } catch {
      // Fallback suggestions if Claude doesn't return valid JSON
      suggestions = [
        "What is an ETF?",
        "How much should I save each month?",
        "Explain my budget health score",
        "What's a good first investment for a beginner?",
      ];
    }

    res.json({ suggestions });
  } catch (err) { next(err); }
});

module.exports = router;
