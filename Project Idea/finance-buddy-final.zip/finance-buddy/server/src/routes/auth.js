// routes/auth.js
"use strict";

const express = require("express");
const bcrypt  = require("bcrypt");
const jwt     = require("jsonwebtoken");
const { db }  = require("../lib/db");

const router     = express.Router();
const SALT_ROUNDS = 12;

function signToken(userId) {
  return jwt.sign({ userId }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN || "24h" });
}

// POST /api/v1/auth/signup
router.post("/signup", async (req, res, next) => {
  try {
    const { email, password, ageConfirmed } = req.body;

    if (!email || !password) return res.status(400).json({ error: "Email and password are required" });
    if (!ageConfirmed)       return res.status(403).json({ error: "You must be 16 or older to create an account" });
    if (password.length < 8) return res.status(400).json({ error: "Password must be at least 8 characters" });

    const existing = await db.user.findUnique({ where: { email } });
    if (existing) return res.status(409).json({ error: "An account with that email already exists" });

    const passwordHash = await bcrypt.hash(password, SALT_ROUNDS);
    const user = await db.user.create({ data: { email, passwordHash, ageConfirmed: true } });

    const token = signToken(user.id);
    res.status(201).json({ userId: user.id, token });
  } catch (err) { next(err); }
});

// POST /api/v1/auth/login
router.post("/login", async (req, res, next) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ error: "Email and password are required" });

    const user = await db.user.findUnique({ where: { email } });
    if (!user) return res.status(401).json({ error: "Invalid email or password" });

    const valid = await bcrypt.compare(password, user.passwordHash);
    if (!valid) return res.status(401).json({ error: "Invalid email or password" });

    const token = signToken(user.id);
    res.json({ token, userId: user.id });
  } catch (err) { next(err); }
});

module.exports = router;
