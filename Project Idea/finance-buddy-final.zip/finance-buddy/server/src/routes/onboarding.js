// routes/onboarding.js
"use strict";

const express             = require("express");
const { db }              = require("../lib/db");
const { claudeChat }      = require("../lib/claude");

const router = express.Router();

// POST /api/v1/onboarding/profile
router.post("/profile", async (req, res, next) => {
  try {
    const { buddyName, goals, knowledgeLevel, riskScore, savingsHabit, investingInterest } = req.body;

    if (!buddyName || !goals || !riskScore) {
      return res.status(400).json({ error: "buddyName, goals, and riskScore are required" });
    }
    if (riskScore < 1 || riskScore > 5) {
      return res.status(400).json({ error: "riskScore must be between 1 and 5" });
    }

    // Generate AI profile summary
    const systemPrompt = `You are Finance Buddy. Generate a warm, encouraging 3-paragraph financial
profile summary for a beginner. Use plain language — no jargon. Mention their goals and risk
tolerance. End with one concrete first step they can take this week.`;

    const userMessage = `Quiz answers:
- Buddy name: ${buddyName}
- Goals: ${goals.join(", ")}
- Knowledge level: ${knowledgeLevel || "BEGINNER"}
- Risk score: ${riskScore}/5
- Savings habit: ${savingsHabit || "NONE"}
- Investing interest: ${investingInterest ? "yes" : "no"}`;

    const profileSummary = await claudeChat({ systemPrompt, userMessage, maxTokens: 600, temperature: 0.7 });

    const profile = await db.userProfile.upsert({
      where:  { userId: req.userId },
      update: { buddyName, goals, knowledgeLevel: knowledgeLevel || "BEGINNER", riskScore: parseInt(riskScore), savingsHabit: savingsHabit || "NONE", investingInterest: !!investingInterest, profileSummary },
      create: { userId: req.userId, buddyName, goals, knowledgeLevel: knowledgeLevel || "BEGINNER", riskScore: parseInt(riskScore), savingsHabit: savingsHabit || "NONE", investingInterest: !!investingInterest, profileSummary },
    });

    res.status(201).json({ profile, aiSummary: profileSummary });
  } catch (err) { next(err); }
});

// GET /api/v1/onboarding/profile
router.get("/profile", async (req, res, next) => {
  try {
    const profile = await db.userProfile.findUnique({ where: { userId: req.userId } });
    if (!profile) return res.status(404).json({ error: "Profile not found — please complete onboarding" });
    res.json({ profile });
  } catch (err) { next(err); }
});

module.exports = router;
