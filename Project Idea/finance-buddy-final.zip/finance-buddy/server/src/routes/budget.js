// routes/budget.js
"use strict";

const express        = require("express");
const { db }         = require("../lib/db");
const { claudeChat } = require("../lib/claude");

const router = express.Router();

// ── Helper: calculate budget totals for a given month ────────────
async function getMonthTotals(userId, month) {
  const start = new Date(`${month}-01`);
  const end   = new Date(start.getFullYear(), start.getMonth() + 1, 0, 23, 59, 59);

  const entries = await db.budgetEntry.findMany({
    where: { userId, date: { gte: start, lte: end } },
    orderBy: { date: "desc" },
  });

  const income   = entries.filter(e => e.type === "INCOME").reduce((s, e) => s + Number(e.amount), 0);
  const expenses = entries.filter(e => e.type === "EXPENSE").reduce((s, e) => s + Number(e.amount), 0);
  const balance  = income - expenses;

  // Category breakdown
  const byCategory = {};
  entries.filter(e => e.type === "EXPENSE").forEach(e => {
    byCategory[e.category] = (byCategory[e.category] || 0) + Number(e.amount);
  });

  // Simple health score: 100 if spending < 80% of income, scaled down from there
  const spendRatio  = income > 0 ? expenses / income : 1;
  const healthScore = Math.max(0, Math.round((1 - spendRatio) * 125));

  return { entries, income, expenses, balance, byCategory, healthScore: Math.min(100, healthScore) };
}

// GET /api/v1/budget/entries?month=2026-03
router.get("/entries", async (req, res, next) => {
  try {
    const month = req.query.month || new Date().toISOString().slice(0, 7);
    const totals = await getMonthTotals(req.userId, month);
    res.json({ entries: totals.entries, totals });
  } catch (err) { next(err); }
});

// POST /api/v1/budget/entries
router.post("/entries", async (req, res, next) => {
  try {
    const { type, amount, category, description, date } = req.body;
    if (!type || !amount || !date) return res.status(400).json({ error: "type, amount, and date are required" });
    if (!["INCOME", "EXPENSE"].includes(type)) return res.status(400).json({ error: "type must be INCOME or EXPENSE" });
    if (amount <= 0) return res.status(400).json({ error: "amount must be greater than 0" });

    const entry = await db.budgetEntry.create({
      data: {
        userId: req.userId,
        type,
        amount,
        category: category || "OTHER",
        description: description || null,
        date: new Date(date),
      },
    });
    res.status(201).json({ entry });
  } catch (err) { next(err); }
});

// PUT /api/v1/budget/entries/:id
router.put("/entries/:id", async (req, res, next) => {
  try {
    const existing = await db.budgetEntry.findUnique({ where: { id: req.params.id } });
    if (!existing || existing.userId !== req.userId) return res.status(404).json({ error: "Entry not found" });

    const entry = await db.budgetEntry.update({
      where: { id: req.params.id },
      data:  req.body,
    });
    res.json({ entry });
  } catch (err) { next(err); }
});

// DELETE /api/v1/budget/entries/:id
router.delete("/entries/:id", async (req, res, next) => {
  try {
    const existing = await db.budgetEntry.findUnique({ where: { id: req.params.id } });
    if (!existing || existing.userId !== req.userId) return res.status(404).json({ error: "Entry not found" });

    await db.budgetEntry.delete({ where: { id: req.params.id } });
    res.status(204).send();
  } catch (err) { next(err); }
});

// GET /api/v1/budget/insight  — Claude-generated budget analysis
router.get("/insight", async (req, res, next) => {
  try {
    const month  = req.query.month || new Date().toISOString().slice(0, 7);
    const totals = await getMonthTotals(req.userId, month);
    const profile = await db.userProfile.findUnique({ where: { userId: req.userId } });

    const systemPrompt = `You are Finance Buddy. Analyze this user's monthly budget and give 2-3 sentences
of plain-language insight. Highlight one positive and one area to improve. Be encouraging, not
judgmental. User risk score: ${profile?.riskScore || 2}/5.`;

    const userMessage = `Monthly budget for ${month}:
- Income: $${totals.income.toFixed(2)}
- Total expenses: $${totals.expenses.toFixed(2)}
- Balance remaining: $${totals.balance.toFixed(2)}
- Health score: ${totals.healthScore}/100
- Spending by category: ${JSON.stringify(totals.byCategory)}`;

    const insight = await claudeChat({ systemPrompt, userMessage, maxTokens: 300, temperature: 0.6 });
    res.json({ insight, healthScore: totals.healthScore });
  } catch (err) { next(err); }
});

// GET /api/v1/budget/goals
router.get("/goals", async (req, res, next) => {
  try {
    const goals = await db.savingsGoal.findMany({ where: { userId: req.userId } });
    res.json({ goals });
  } catch (err) { next(err); }
});

// POST /api/v1/budget/goals
router.post("/goals", async (req, res, next) => {
  try {
    const { label, targetAmount, deadline } = req.body;
    if (!label || !targetAmount) return res.status(400).json({ error: "label and targetAmount are required" });

    const goal = await db.savingsGoal.create({
      data: {
        userId: req.userId,
        label,
        targetAmount,
        deadline: deadline ? new Date(deadline) : null,
      },
    });
    res.status(201).json({ goal });
  } catch (err) { next(err); }
});

module.exports = router;
