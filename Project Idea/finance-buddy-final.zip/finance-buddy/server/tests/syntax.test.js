// tests/syntax.test.js
// Full automated validation — runs without any npm packages installed
"use strict";

const fs   = require("fs");
const path = require("path");
const { test, describe } = require("node:test");
const assert = require("node:assert/strict");
const vm     = require("vm");

// ── Helpers ──────────────────────────────────────────────────────

function fileOk(relPath) {
  const full = path.join(__dirname, "..", relPath);
  assert.ok(fs.existsSync(full),        `MISSING: ${relPath}`);
  assert.ok(fs.statSync(full).size > 0, `EMPTY:   ${relPath}`);
}

function syntaxOk(relPath) {
  const full = path.join(__dirname, "..", relPath);
  const code = fs.readFileSync(full, "utf8");
  try {
    new vm.Script(code, { filename: relPath });
  } catch (e) {
    assert.fail(`SYNTAX ERROR in ${relPath}: ${e.message}`);
  }
}

function read(relPath) {
  return fs.readFileSync(path.join(__dirname, "..", relPath), "utf8");
}

function readClient(relPath) {
  return fs.readFileSync(path.join(__dirname, "../../client", relPath), "utf8");
}

// ══════════════════════════════════════════════════════════════════

describe("1. File Structure — Server", () => {
  const required = [
    "package.json",
    ".env.example",
    "src/index.js",
    "src/middleware/authenticate.js",
    "src/middleware/errorHandler.js",
    "src/lib/claude.js",
    "src/lib/db.js",
    "src/lib/market.js",
    "src/routes/auth.js",
    "src/routes/onboarding.js",
    "src/routes/budget.js",
    "src/routes/portfolio.js",
    "src/routes/chat.js",
    "src/routes/insights.js",
    "src/routes/market.js",
    "src/prisma/schema.prisma",
    "src/prisma/seed.js",
  ];
  for (const f of required) {
    test(`exists: ${f}`, () => fileOk(f));
  }
});

// ──────────────────────────────────────────────────────────────────

describe("2. JavaScript Syntax — All Server Files", () => {
  const jsFiles = [
    "src/index.js",
    "src/middleware/authenticate.js",
    "src/middleware/errorHandler.js",
    "src/lib/claude.js",
    "src/lib/db.js",
    "src/lib/market.js",
    "src/routes/auth.js",
    "src/routes/onboarding.js",
    "src/routes/budget.js",
    "src/routes/portfolio.js",
    "src/routes/chat.js",
    "src/routes/insights.js",
    "src/routes/market.js",
    "src/prisma/seed.js",
  ];
  for (const f of jsFiles) {
    test(`valid syntax: ${f}`, () => syntaxOk(f));
  }
});

// ──────────────────────────────────────────────────────────────────

describe("3. package.json Integrity", () => {
  test("parses as valid JSON", () => {
    const pkg = JSON.parse(read("package.json"));
    assert.ok(pkg.name,         "name field missing");
    assert.ok(pkg.dependencies, "dependencies field missing");
    assert.ok(pkg.scripts,      "scripts field missing");
  });

  test("contains all required dependencies", () => {
    const pkg  = JSON.parse(read("package.json"));
    const deps = { ...pkg.dependencies, ...pkg.devDependencies };
    for (const dep of ["express", "bcrypt", "jsonwebtoken", "dotenv", "@prisma/client", "@anthropic-ai/sdk"]) {
      assert.ok(deps[dep], `Missing dependency: ${dep}`);
    }
  });

  test("has dev, start, and db scripts", () => {
    const scripts = JSON.parse(read("package.json")).scripts;
    assert.ok(scripts.dev,            "Missing 'dev' script");
    assert.ok(scripts.start,          "Missing 'start' script");
    assert.ok(scripts["db:migrate"],  "Missing 'db:migrate' script");
    assert.ok(scripts["db:generate"], "Missing 'db:generate' script");
    assert.ok(scripts["db:seed"],     "Missing 'db:seed' script");
  });
});

// ──────────────────────────────────────────────────────────────────

describe("4. .env.example Completeness", () => {
  test("contains all required environment variables", () => {
    const env = read(".env.example");
    for (const key of ["DATABASE_URL", "JWT_SECRET", "ANTHROPIC_API_KEY", "ALPHAVANTAGE_API_KEY", "PORT", "CLIENT_ORIGIN", "JWT_EXPIRES_IN"]) {
      assert.ok(env.includes(key), `Missing env var: ${key}`);
    }
  });

  test("does not contain real credentials", () => {
    const env = read(".env.example");
    assert.ok(!env.includes("sk-ant-api"),  ".env.example contains a real Anthropic key!");
    assert.ok(!env.includes("postgres:password@") || env.includes("password@localhost"), "May contain real DB credentials");
  });
});

// ──────────────────────────────────────────────────────────────────

describe("5. Prisma Schema", () => {
  test("contains all 6 required models", () => {
    const schema = read("src/prisma/schema.prisma");
    for (const m of ["User", "UserProfile", "BudgetEntry", "SavingsGoal", "Holding", "InsightCard"]) {
      assert.ok(schema.includes(`model ${m} `), `Missing model: ${m}`);
    }
  });

  test("contains all required enums", () => {
    const schema = read("src/prisma/schema.prisma");
    for (const e of ["KnowledgeLevel", "SavingsHabit", "EntryType", "Category", "InsightType", "RiskLabel", "InsightStatus"]) {
      assert.ok(schema.includes(`enum ${e}`), `Missing enum: ${e}`);
    }
  });

  test("configured for PostgreSQL", () => {
    assert.ok(read("src/prisma/schema.prisma").includes('provider = "postgresql"'));
  });

  test("all child models have cascade deletes", () => {
    const schema = read("src/prisma/schema.prisma");
    const count  = (schema.match(/onDelete: Cascade/g) || []).length;
    assert.ok(count >= 5, `Expected ≥5 cascade deletes, found ${count}`);
  });

  test("Holding has unique constraint on userId + ticker", () => {
    assert.ok(read("src/prisma/schema.prisma").includes("@@unique([userId, ticker])"), "Missing @@unique([userId, ticker]) constraint on Holding");
  });

  test("BudgetEntry has index on userId + date", () => {
    assert.ok(read("src/prisma/schema.prisma").includes("@@index([userId, date])"), "Missing compound index on BudgetEntry");
  });
});

// ──────────────────────────────────────────────────────────────────

describe("6. Route Files — Structure & Correctness", () => {
  test("auth.js exports router with signup and login", () => {
    const code = read("src/routes/auth.js");
    assert.ok(code.includes("module.exports = router"), "Missing module.exports");
    assert.ok(code.includes('router.post("/signup"'),   "Missing /signup route");
    assert.ok(code.includes('router.post("/login"'),    "Missing /login route");
  });

  test("auth.js enforces age gate (ageConfirmed)", () => {
    const code = read("src/routes/auth.js");
    assert.ok(code.includes("ageConfirmed"),  "Missing ageConfirmed check");
    assert.ok(code.includes("403"),           "Missing 403 response for age gate failure");
  });

  test("auth.js uses bcrypt with cost factor", () => {
    const code = read("src/routes/auth.js");
    assert.ok(code.includes("bcrypt.hash"),    "Missing bcrypt.hash");
    assert.ok(code.includes("bcrypt.compare"), "Missing bcrypt.compare");
    assert.ok(code.match(/SALT_ROUNDS\s*=\s*1[2-9]/), "Salt rounds should be ≥ 12");
  });

  test("budget.js has full CRUD + insight + goals", () => {
    const code = read("src/routes/budget.js");
    assert.ok(code.includes("router.get"),    "Missing GET");
    assert.ok(code.includes("router.post"),   "Missing POST");
    assert.ok(code.includes("router.put"),    "Missing PUT");
    assert.ok(code.includes("router.delete"), "Missing DELETE");
    assert.ok(code.includes('"/insight"'),    "Missing /insight endpoint");
    assert.ok(code.includes('"/goals"'),      "Missing /goals endpoint");
  });

  test("budget.js calculates healthScore", () => {
    assert.ok(read("src/routes/budget.js").includes("healthScore"), "Missing healthScore calculation");
  });

  test("portfolio.js has buy, sell, watchlist, and explain", () => {
    const code = read("src/routes/portfolio.js");
    assert.ok(code.includes('"/buy"'),       "Missing /buy route");
    assert.ok(code.includes('"/sell"'),      "Missing /sell route");
    assert.ok(code.includes('"/watchlist"'), "Missing /watchlist route");
    assert.ok(code.includes('"/explain/'),   "Missing /explain/:ticker route");
  });

  test("portfolio.js averages cost on repeat buys", () => {
    assert.ok(read("src/routes/portfolio.js").includes("newAvgCost"), "Missing average cost calculation on repeat buy");
  });

  test("chat.js uses claudeStream for SSE", () => {
    const code = read("src/routes/chat.js");
    assert.ok(code.includes("claudeStream"),  "Missing claudeStream usage");
    assert.ok(code.includes("suggestions"),   "Missing /suggestions endpoint");
  });

  test("chat.js injects user context into system prompt", () => {
    assert.ok(read("src/routes/chat.js").includes("buildUserContext"), "Missing buildUserContext call");
  });

  test("insights.js has generate, accept, and dismiss", () => {
    const code = read("src/routes/insights.js");
    assert.ok(code.includes('"/generate"'),    "Missing /generate route");
    assert.ok(code.includes('"/:id/accept"'),  "Missing /:id/accept route");
    assert.ok(code.includes('"/:id/dismiss"'), "Missing /:id/dismiss route");
  });

  test("insights.js returns structured JSON from Claude", () => {
    const code = read("src/routes/insights.js");
    assert.ok(code.includes("JSON.parse"), "insights.js should parse Claude's JSON response");
    assert.ok(code.includes("riskLabel"),  "insights.js should extract riskLabel from Claude");
  });

  test("market.js translates news via Claude", () => {
    const code = read("src/routes/market.js");
    assert.ok(code.includes("claudeChat"), "market.js should translate news via Claude");
    assert.ok(code.includes("translation"), "market.js missing translation field in response");
  });
});

// ──────────────────────────────────────────────────────────────────

describe("7. Security & Safety", () => {
  test("claude.js has global safety system prompt", () => {
    const code = read("src/lib/claude.js");
    assert.ok(code.includes("SAFETY_SYSTEM"),  "Missing SAFETY_SYSTEM constant");
    assert.ok(code.includes("educational"),    "Safety prompt must mention 'educational'");
    assert.ok(code.includes("never"),          "Safety prompt must include prohibition language");
  });

  test("claude.js prepends safety prompt to ALL calls", () => {
    const code = read("src/lib/claude.js");
    const safetyUsageCount = (code.match(/SAFETY_SYSTEM/g) || []).length;
    assert.ok(safetyUsageCount >= 3, `SAFETY_SYSTEM should be used in claudeChat, claudeMultiTurn, and claudeStream — found ${safetyUsageCount} usages`);
  });

  test("authenticate.js verifies JWT and returns 401", () => {
    const code = read("src/middleware/authenticate.js");
    assert.ok(code.includes("Bearer"),      "Missing Bearer token check");
    assert.ok(code.includes("jwt.verify"),  "Missing jwt.verify");
    assert.ok(code.includes("401"),         "Missing 401 response");
    assert.ok(code.includes("req.userId"),  "Missing req.userId assignment");
  });

  test("index.js applies authenticate to all protected routes", () => {
    const code = read("src/index.js");
    assert.ok(code.includes("authenticate, onboardRoutes"),   "onboarding not protected");
    assert.ok(code.includes("authenticate, budgetRoutes"),    "budget not protected");
    assert.ok(code.includes("authenticate, portfolioRoutes"), "portfolio not protected");
    assert.ok(code.includes("authenticate, chatRoutes"),      "chat not protected");
    assert.ok(code.includes("authenticate, insightRoutes"),   "insights not protected");
  });

  test("index.js auth routes are public (no authenticate)", () => {
    const code = read("src/index.js");
    assert.ok(code.includes('use("/api/v1/auth", authRoutes)'), "Auth route should be public");
    assert.ok(!code.includes('use("/api/v1/auth", authenticate'), "Auth route must NOT require JWT");
  });

  test("lib/market.js uses env var for API key", () => {
    const code = read("src/lib/market.js");
    assert.ok(code.includes("process.env.ALPHAVANTAGE_API_KEY"), "Market API key must come from env");
    assert.ok(!code.match(/apikey\s*[:=]\s*["'][A-Z0-9]{15,}/), "Market file must not hardcode API key");
  });

  test("errorHandler.js handles Prisma P2002 and P2025", () => {
    const code = read("src/middleware/errorHandler.js");
    assert.ok(code.includes("P2002"), "Missing Prisma unique constraint handler");
    assert.ok(code.includes("P2025"), "Missing Prisma not-found handler");
  });
});

// ──────────────────────────────────────────────────────────────────

describe("8. AI Integration Quality", () => {
  test("claude.js exports claudeChat, claudeMultiTurn, claudeStream, buildUserContext", () => {
    const code = read("src/lib/claude.js");
    assert.ok(code.includes("claudeChat"),        "Missing claudeChat export");
    assert.ok(code.includes("claudeMultiTurn"),    "Missing claudeMultiTurn export");
    assert.ok(code.includes("claudeStream"),       "Missing claudeStream export");
    assert.ok(code.includes("buildUserContext"),   "Missing buildUserContext export");
  });

  test("claudeStream sets correct SSE headers", () => {
    const code = read("src/lib/claude.js");
    assert.ok(code.includes("text/event-stream"), "Missing Content-Type: text/event-stream");
    assert.ok(code.includes("no-cache"),          "Missing Cache-Control: no-cache");
    assert.ok(code.includes("[DONE]"),            "Missing [DONE] SSE terminator");
  });

  test("buildUserContext includes riskScore, goals, and holdings", () => {
    const code = read("src/lib/claude.js");
    assert.ok(code.includes("riskScore"),  "buildUserContext missing riskScore");
    assert.ok(code.includes("goals"),      "buildUserContext missing goals");
    assert.ok(code.includes("holdings"),   "buildUserContext missing holdings");
  });

  test("claude.js targets correct model", () => {
    assert.ok(read("src/lib/claude.js").includes("claude-sonnet-4-20250514"), "Wrong or missing model string");
  });

  test("onboarding route calls Claude for profile summary", () => {
    assert.ok(read("src/routes/onboarding.js").includes("claudeChat"), "Onboarding missing Claude call");
  });
});

// ──────────────────────────────────────────────────────────────────

describe("9. Client Structure", () => {
  const clientFiles = [
    ["package.json",              "package.json"],
    ["vite.config.ts",            "vite.config.ts"],
    ["index.html",                "index.html"],
    ["src/main.tsx",              "src/main.tsx"],
    ["src/lib/api.ts",            "src/lib/api.ts"],
    ["src/stores/authStore.ts",   "src/stores/authStore.ts"],
    ["src/stores/chatStore.ts",   "src/stores/chatStore.ts"],
  ];
  for (const [label, f] of clientFiles) {
    test(`exists: ${label}`, () => {
      const full = path.join(__dirname, "../../client", f);
      assert.ok(fs.existsSync(full), `MISSING: client/${f}`);
    });
  }

  test("all 7 page stubs exist", () => {
    const pages = ["LoginPage", "SignupPage", "OnboardingPage", "DashboardPage", "BudgetPage", "PortfolioPage", "LearnPage"];
    for (const p of pages) {
      const full = path.join(__dirname, `../../client/src/pages/${p}.tsx`);
      assert.ok(fs.existsSync(full), `MISSING page: ${p}.tsx`);
    }
  });

  test("api.ts exports api object and streamChat", () => {
    const code = readClient("src/lib/api.ts");
    assert.ok(code.includes("export const api"),   "Missing api export");
    assert.ok(code.includes("export async function streamChat"), "Missing streamChat export");
    assert.ok(code.includes("[DONE]"),              "Missing [DONE] SSE handling in streamChat");
  });

  test("api.ts never hardcodes API keys", () => {
    const code = readClient("src/lib/api.ts");
    assert.ok(!code.includes("sk-ant"), "api.ts must not contain Anthropic key");
    assert.ok(!code.includes("apikey"), "api.ts must not contain market data key");
  });

  test("authStore.ts persists and clears token", () => {
    const code = readClient("src/stores/authStore.ts");
    assert.ok(code.includes("localStorage.setItem"),    "Missing token persistence");
    assert.ok(code.includes("localStorage.removeItem"), "Missing token cleanup on logout");
    assert.ok(code.includes("hydrate"),                 "Missing hydrate function for page refresh");
  });

  test("chatStore.ts handles streaming state correctly", () => {
    const code = readClient("src/stores/chatStore.ts");
    assert.ok(code.includes("isStreaming"),        "Missing isStreaming flag");
    assert.ok(code.includes("streamChat"),         "Missing streamChat usage");
    assert.ok(code.includes("last.content +="),   "Missing token-by-token content append logic");
  });

  test("main.tsx protects routes with Protected wrapper", () => {
    const code = readClient("src/main.tsx");
    assert.ok(code.includes("Protected"),   "Missing Protected route wrapper");
    assert.ok(code.includes("/dashboard"),  "Missing /dashboard route");
    assert.ok(code.includes("/login"),      "Missing /login route");
    assert.ok(code.includes("/onboarding"), "Missing /onboarding route");
    assert.ok(code.includes("Navigate"),    "Missing Navigate redirect");
  });

  test("vite.config.ts proxies /api to port 3001", () => {
    const code = readClient("vite.config.ts");
    assert.ok(code.includes("proxy"),           "Missing proxy config");
    assert.ok(code.includes("localhost:3001"),  "Not proxying to port 3001");
    assert.ok(code.includes('"/api"'),          "Proxy not targeting /api prefix");
  });

  test("client package.json has correct dependencies", () => {
    const pkg  = JSON.parse(readClient("package.json"));
    const deps = { ...pkg.dependencies, ...pkg.devDependencies };
    for (const dep of ["react", "react-dom", "react-router-dom", "zustand", "vite", "tailwindcss"]) {
      assert.ok(deps[dep], `Client missing dependency: ${dep}`);
    }
  });
});

// ──────────────────────────────────────────────────────────────────

describe("10. Seed File", () => {
  test("seed.js creates demo user, profile, budget, holdings, and insight", () => {
    const code = read("src/prisma/seed.js");
    assert.ok(code.includes("demo@financebuddy.dev"), "Missing demo user email");
    assert.ok(code.includes("db.user.upsert"),        "Missing user seed");
    assert.ok(code.includes("db.userProfile"),        "Missing profile seed");
    assert.ok(code.includes("db.budgetEntry"),        "Missing budget entry seed");
    assert.ok(code.includes("db.holding"),            "Missing holding seed");
    assert.ok(code.includes("db.insightCard"),        "Missing insight card seed");
  });

  test("seed.js disconnects Prisma after completion", () => {
    assert.ok(read("src/prisma/seed.js").includes("$disconnect"), "Missing db.$disconnect() in seed");
  });
});

// ──────────────────────────────────────────────────────────────────

describe("11. UI Components & Pages", () => {
  const components = [
    "src/components/ui/index.tsx",
    "src/components/layout/AppLayout.tsx",
    "src/components/ai/ChatWidget.tsx",
    "src/components/ai/InsightCard.tsx",
  ];
  for (const f of components) {
    test(`component exists: ${path.basename(f)}`, () => {
      const full = path.join(__dirname, "../../client", f);
      assert.ok(fs.existsSync(full), `MISSING component: ${f}`);
      assert.ok(fs.statSync(full).size > 100, `Component is too small (likely empty stub): ${f}`);
    });
  }

  test("ui/index.tsx exports Button, Card, Input, Badge, Spinner", () => {
    const code = readClient("src/components/ui/index.tsx");
    for (const comp of ["Button", "Card", "Input", "Badge", "Spinner", "Alert", "ProgressBar", "StatCard"]) {
      assert.ok(code.includes(`export function ${comp}`), `Missing export: ${comp}`);
    }
  });

  test("AppLayout.tsx has sidebar nav with all 4 routes", () => {
    const code = readClient("src/components/layout/AppLayout.tsx");
    for (const route of ["/dashboard", "/budget", "/portfolio", "/learn"]) {
      assert.ok(code.includes(route), `AppLayout missing nav route: ${route}`);
    }
    assert.ok(code.includes("logout"), "AppLayout missing logout action");
  });

  test("ChatWidget.tsx uses streaming and shows suggestions", () => {
    const code = readClient("src/components/ai/ChatWidget.tsx");
    assert.ok(code.includes("isStreaming"),   "ChatWidget missing isStreaming");
    assert.ok(code.includes("suggestions"),   "ChatWidget missing suggestions");
    assert.ok(code.includes("sendMessage"),   "ChatWidget missing sendMessage call");
    assert.ok(code.includes("text-event-stream") || code.includes("streaming"), "ChatWidget missing streaming indicator");
  });

  test("InsightCard.tsx has accept and dismiss actions", () => {
    const code = readClient("src/components/ai/InsightCard.tsx");
    assert.ok(code.includes("accept"),   "InsightCard missing accept action");
    assert.ok(code.includes("dismiss"),  "InsightCard missing dismiss action");
    assert.ok(code.includes("riskLabel"), "InsightCard missing riskLabel display");
  });

  const pages = [
    ["LoginPage.tsx",      ["login", "email", "password", "Sign In"]],
    ["SignupPage.tsx",      ["signup", "ageConfirmed", "16", "Terms"]],
    ["OnboardingPage.tsx",  ["buddyName", "goals", "riskScore", "summary"]],
    ["DashboardPage.tsx",   ["AppLayout", "InsightCard", "StatCard", "ChatWidget"]],
    ["BudgetPage.tsx",      ["INCOME", "EXPENSE", "category", "insight"]],
    ["PortfolioPage.tsx",   ["holdings", "watchlist", "buy", "explain"]],
    ["LearnPage.tsx",       ["LESSONS", "openLesson", "ChatWidget", "Badge"]],
  ];
  for (const [file, keywords] of pages) {
    test(`${file} has correct content`, () => {
      const code = readClient(`src/pages/${file}`);
      assert.ok(code.length > 500, `${file} looks like a stub — too short`);
      for (const kw of keywords) {
        assert.ok(code.includes(kw), `${file} missing expected content: "${kw}"`);
      }
    });
  }

  test("all pages include AppLayout (except auth pages)", () => {
    for (const page of ["DashboardPage", "BudgetPage", "PortfolioPage", "LearnPage"]) {
      const code = readClient(`src/pages/${page}.tsx`);
      assert.ok(code.includes("AppLayout"), `${page} missing AppLayout wrapper`);
    }
  });

  test("all protected pages include ChatWidget", () => {
    for (const page of ["DashboardPage", "BudgetPage", "PortfolioPage", "LearnPage"]) {
      const code = readClient(`src/pages/${page}.tsx`);
      assert.ok(code.includes("ChatWidget"), `${page} missing ChatWidget`);
    }
  });

  test("age gate is present in SignupPage", () => {
    const code = readClient("src/pages/SignupPage.tsx");
    assert.ok(code.includes("ageConfirmed"),    "SignupPage missing ageConfirmed state");
    assert.ok(code.includes("16"),              "SignupPage missing age requirement text");
    assert.ok(code.includes("checkbox"),        "SignupPage missing age confirmation checkbox");
    assert.ok(code.includes("financial advisor"), "SignupPage missing financial advisor disclaimer");
  });

  test("DashboardPage handles missing profile gracefully", () => {
    const code = readClient("src/pages/DashboardPage.tsx");
    assert.ok(code.includes("onboarding") || code.includes("profile"), "DashboardPage should handle missing profile");
  });
});

// ──────────────────────────────────────────────────────────────────

describe("12. New Files — Stores, Hooks, Deployment", () => {

  // Stores
  test("budgetStore.ts exists and exports correct actions", () => {
    const code = readClient("src/stores/budgetStore.ts");
    assert.ok(code.length > 200,        "budgetStore.ts looks like a stub");
    assert.ok(code.includes("fetchEntries"),  "Missing fetchEntries");
    assert.ok(code.includes("addEntry"),      "Missing addEntry");
    assert.ok(code.includes("deleteEntry"),   "Missing deleteEntry");
    assert.ok(code.includes("fetchInsight"),  "Missing fetchInsight");
    assert.ok(code.includes("fetchGoals"),    "Missing fetchGoals");
    assert.ok(code.includes("addGoal"),       "Missing addGoal");
  });

  test("portfolioStore.ts exists and exports correct actions", () => {
    const code = readClient("src/stores/portfolioStore.ts");
    assert.ok(code.length > 200,             "portfolioStore.ts looks like a stub");
    assert.ok(code.includes("fetchHoldings"),      "Missing fetchHoldings");
    assert.ok(code.includes("simulateBuy"),        "Missing simulateBuy");
    assert.ok(code.includes("simulateSell"),       "Missing simulateSell");
    assert.ok(code.includes("addToWatchlist"),     "Missing addToWatchlist");
    assert.ok(code.includes("removeFromWatchlist"),"Missing removeFromWatchlist");
    assert.ok(code.includes("explainStock"),       "Missing explainStock");
    assert.ok(code.includes("generateInsight"),    "Missing generateInsight");
  });

  test("profileStore.ts exists and exports fetchProfile + clearProfile", () => {
    const code = readClient("src/stores/profileStore.ts");
    assert.ok(code.includes("fetchProfile"),  "Missing fetchProfile");
    assert.ok(code.includes("clearProfile"),  "Missing clearProfile");
    assert.ok(code.includes("hasProfile"),    "Missing hasProfile flag");
  });

  test("types.ts exports all required TypeScript interfaces", () => {
    const code = readClient("src/types.ts");
    for (const t of ["UserProfile","BudgetEntry","SavingsGoal","Holding","InsightCard",
                     "EntryType","Category","RiskLabel","InsightStatus","ChatMessage"]) {
      assert.ok(code.includes(t), `types.ts missing: ${t}`);
    }
  });

  // Hooks
  test("hooks/useAuth.ts exists and redirects on unauthenticated", () => {
    const full = path.join(__dirname, "../../client/src/hooks/useAuth.ts");
    assert.ok(fs.existsSync(full), "MISSING: hooks/useAuth.ts");
    const code = readClient("src/hooks/useAuth.ts");
    assert.ok(code.includes("navigate"),  "useAuth should call navigate for redirect");
    assert.ok(code.includes("isAuthed"),  "useAuth should check isAuthed");
  });

  test("hooks/usePageTitle.ts exists and sets document.title", () => {
    const full = path.join(__dirname, "../../client/src/hooks/usePageTitle.ts");
    assert.ok(fs.existsSync(full), "MISSING: hooks/usePageTitle.ts");
    const code = readClient("src/hooks/usePageTitle.ts");
    assert.ok(code.includes("document.title"), "usePageTitle should set document.title");
  });

  // Deployment
  test("client/vercel.json exists and has SPA rewrite rule", () => {
    const full = path.join(__dirname, "../../client/vercel.json");
    assert.ok(fs.existsSync(full), "MISSING: client/vercel.json");
    const json = JSON.parse(fs.readFileSync(full, "utf8"));
    assert.ok(json.rewrites || json.routes, "vercel.json missing rewrite rules for SPA");
  });

  test("server/railway.toml or render.yaml exists for backend deployment", () => {
    const railway = path.join(__dirname, "../railway.toml");
    const render  = path.join(__dirname, "../render.yaml");
    assert.ok(fs.existsSync(railway) || fs.existsSync(render),
      "MISSING: neither railway.toml nor render.yaml found in server/");
  });

  test("server/railway.toml has health check path", () => {
    const full = path.join(__dirname, "../railway.toml");
    if (!fs.existsSync(full)) return; // render.yaml is alternative
    const content = fs.readFileSync(full, "utf8");
    assert.ok(content.includes("health"), "railway.toml missing health check config");
  });

  // Root monorepo
  test("root package.json has dev and test scripts", () => {
    const full = path.join(__dirname, "../../package.json");
    assert.ok(fs.existsSync(full), "MISSING: root package.json");
    const pkg = JSON.parse(fs.readFileSync(full, "utf8"));
    assert.ok(pkg.scripts.dev,           "Root package.json missing 'dev' script");
    assert.ok(pkg.scripts.test,          "Root package.json missing 'test' script");
    assert.ok(pkg.scripts["install:all"],"Root package.json missing 'install:all' script");
  });

  test("client/postcss.config.js exists (required for Tailwind)", () => {
    const full = path.join(__dirname, "../../client/postcss.config.js");
    assert.ok(fs.existsSync(full), "MISSING: client/postcss.config.js — Tailwind will not work without it");
    const code = fs.readFileSync(full, "utf8");
    assert.ok(code.includes("tailwindcss"), "postcss.config.js not configured for Tailwind");
  });

  // Server env validation
  test("lib/validateEnv.js exists and checks required vars", () => {
    const full = path.join(__dirname, "../src/lib/validateEnv.js");
    assert.ok(fs.existsSync(full), "MISSING: lib/validateEnv.js");
    const code = fs.readFileSync(full, "utf8");
    assert.ok(code.includes("DATABASE_URL"),     "validateEnv missing DATABASE_URL check");
    assert.ok(code.includes("JWT_SECRET"),        "validateEnv missing JWT_SECRET check");
    assert.ok(code.includes("ANTHROPIC_API_KEY"), "validateEnv missing ANTHROPIC_API_KEY check");
    assert.ok(code.includes("process.exit(1)"),   "validateEnv must exit process on missing vars");
  });

  test("index.js calls validateEnv on startup", () => {
    const code = fs.readFileSync(path.join(__dirname, "../src/index.js"), "utf8");
    assert.ok(code.includes("validateEnv"), "index.js must call validateEnv() on startup");
  });

  // Refactored pages use stores
  test("DashboardPage uses stores instead of direct API calls", () => {
    const code = readClient("src/pages/DashboardPage.tsx");
    assert.ok(code.includes("useBudgetStore"),    "DashboardPage should use useBudgetStore");
    assert.ok(code.includes("usePortfolioStore"), "DashboardPage should use usePortfolioStore");
    assert.ok(code.includes("useProfileStore"),   "DashboardPage should use useProfileStore");
    assert.ok(!code.includes('api.get("/budget')  && !code.includes("api.get<any>(\"/budget"),
      "DashboardPage should not make direct /budget API calls — use store instead");
  });

  test("BudgetPage uses budgetStore instead of direct API calls", () => {
    const code = readClient("src/pages/BudgetPage.tsx");
    assert.ok(code.includes("useBudgetStore"), "BudgetPage should use useBudgetStore");
    assert.ok(!code.includes('api.get("/budget') && !code.includes("api.post(\"/budget"),
      "BudgetPage should not make direct API calls — use store instead");
  });
});
