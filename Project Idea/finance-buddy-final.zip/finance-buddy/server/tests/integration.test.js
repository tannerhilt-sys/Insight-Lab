// tests/integration.test.js
// Self-contained integration tests — no npm packages required
// Tests core business logic that would run inside each route handler
"use strict";

const { test, describe } = require("node:test");
const assert = require("node:assert/strict");
const crypto = require("crypto");

// ── Pure business logic extracted from routes ─────────────────────
// These mirror exactly what the route handlers do, testable without Express

function calculateBudgetTotals(entries) {
  const income   = entries.filter(e => e.type === "INCOME").reduce((s, e) => s + Number(e.amount), 0);
  const expenses = entries.filter(e => e.type === "EXPENSE").reduce((s, e) => s + Number(e.amount), 0);
  const balance  = income - expenses;
  const byCategory = {};
  entries.filter(e => e.type === "EXPENSE").forEach(e => {
    byCategory[e.category] = (byCategory[e.category] || 0) + Number(e.amount);
  });
  const spendRatio  = income > 0 ? expenses / income : 1;
  const healthScore = Math.min(100, Math.max(0, Math.round((1 - spendRatio) * 125)));
  return { income, expenses, balance, byCategory, healthScore };
}

function calculateRiskScore(answers) {
  // Quiz answers are 1-5 per question, averaged and rounded
  if (!Array.isArray(answers) || answers.length === 0) return 2;
  const avg = answers.reduce((s, a) => s + a, 0) / answers.length;
  return Math.min(5, Math.max(1, Math.round(avg)));
}

function validateSignupInput({ email, password, ageConfirmed }) {
  if (!email || !password)  return { valid: false, status: 400, error: "Email and password are required" };
  if (!ageConfirmed)        return { valid: false, status: 403, error: "You must be 16 or older" };
  if (password.length < 8)  return { valid: false, status: 400, error: "Password must be at least 8 characters" };
  if (!email.includes("@")) return { valid: false, status: 400, error: "Invalid email address" };
  return { valid: true };
}

function validateBudgetEntry({ type, amount, date }) {
  if (!type || !amount || !date) return { valid: false, error: "type, amount, and date are required" };
  if (!["INCOME", "EXPENSE"].includes(type)) return { valid: false, error: "type must be INCOME or EXPENSE" };
  if (amount <= 0) return { valid: false, error: "amount must be greater than 0" };
  return { valid: true };
}

function calculatePortfolioAvgCost(existingShares, existingAvgCost, newShares, newPrice) {
  const totalShares = existingShares + newShares;
  const newAvgCost  = ((existingAvgCost * existingShares) + (newPrice * newShares)) / totalShares;
  return { totalShares, newAvgCost };
}

function buildUserContext(profile, budgetSummary, holdings) {
  const holdingStr = holdings.length
    ? holdings.map(h => `${h.ticker} x${h.shares} shares`).join(", ")
    : "No holdings yet";
  return `USER CONTEXT:\n- Buddy name: ${profile.buddyName}\n- Risk score: ${profile.riskScore}/5\n- Goals: ${profile.goals.join(", ")}\n- Portfolio: ${holdingStr}`;
}

function validateInsightJSON(raw) {
  try {
    const parsed = JSON.parse(raw.replace(/```json|```/g, "").trim());
    return !!(parsed.title && parsed.body && parsed.riskLabel && parsed.actionLabel);
  } catch { return false; }
}

// Minimal JWT simulation (matches what jsonwebtoken does)
function signTestToken(userId, secret) {
  const header  = Buffer.from(JSON.stringify({ alg: "HS256", typ: "JWT" })).toString("base64url");
  const payload = Buffer.from(JSON.stringify({ userId, iat: Math.floor(Date.now() / 1000) })).toString("base64url");
  const sig     = crypto.createHmac("sha256", secret).update(`${header}.${payload}`).digest("base64url");
  return `${header}.${payload}.${sig}`;
}

function verifyTestToken(token, secret) {
  const [header, payload, sig] = token.split(".");
  const expected = crypto.createHmac("sha256", secret).update(`${header}.${payload}`).digest("base64url");
  if (sig !== expected) throw new Error("Invalid signature");
  return JSON.parse(Buffer.from(payload, "base64url").toString());
}

// ══════════════════════════════════════════════════════════════════

describe("1. Signup Input Validation", () => {
  test("valid input passes", () => {
    const result = validateSignupInput({ email: "user@test.com", password: "password123", ageConfirmed: true });
    assert.ok(result.valid);
  });

  test("missing ageConfirmed returns 403", () => {
    const result = validateSignupInput({ email: "user@test.com", password: "password123", ageConfirmed: false });
    assert.equal(result.valid, false);
    assert.equal(result.status, 403);
    assert.ok(result.error.includes("16"));
  });

  test("password shorter than 8 chars returns 400", () => {
    const result = validateSignupInput({ email: "user@test.com", password: "short", ageConfirmed: true });
    assert.equal(result.valid, false);
    assert.equal(result.status, 400);
  });

  test("missing email returns 400", () => {
    const result = validateSignupInput({ email: "", password: "password123", ageConfirmed: true });
    assert.equal(result.valid, false);
    assert.equal(result.status, 400);
  });

  test("missing password returns 400", () => {
    const result = validateSignupInput({ email: "user@test.com", password: "", ageConfirmed: true });
    assert.equal(result.valid, false);
    assert.equal(result.status, 400);
  });

  test("invalid email format is caught", () => {
    const result = validateSignupInput({ email: "notanemail", password: "password123", ageConfirmed: true });
    assert.equal(result.valid, false);
  });
});

// ──────────────────────────────────────────────────────────────────

describe("2. Budget Calculations", () => {
  const sampleEntries = [
    { type: "INCOME",  amount: 3200, category: "OTHER" },
    { type: "EXPENSE", amount: 1100, category: "HOUSING" },
    { type: "EXPENSE", amount: 400,  category: "FOOD" },
    { type: "EXPENSE", amount: 300,  category: "TRANSPORT" },
    { type: "EXPENSE", amount: 200,  category: "ENTERTAINMENT" },
  ];

  test("income totals correctly", () => {
    const totals = calculateBudgetTotals(sampleEntries);
    assert.equal(totals.income, 3200);
  });

  test("expenses total correctly", () => {
    const totals = calculateBudgetTotals(sampleEntries);
    assert.equal(totals.expenses, 2000);
  });

  test("balance is income minus expenses", () => {
    const totals = calculateBudgetTotals(sampleEntries);
    assert.equal(totals.balance, 1200);
  });

  test("health score is between 0 and 100", () => {
    const totals = calculateBudgetTotals(sampleEntries);
    assert.ok(totals.healthScore >= 0 && totals.healthScore <= 100,
      `Health score ${totals.healthScore} out of range`);
  });

  test("spending 37.5% of income gives ~53 health score (75% spending gives lower)", () => {
    // 2000/3200 = 62.5% spending → (1 - 0.625) * 125 = 46.9 ≈ 47
    const totals = calculateBudgetTotals(sampleEntries);
    assert.ok(totals.healthScore >= 40 && totals.healthScore <= 60,
      `Expected score around 47, got ${totals.healthScore}`);
  });

  test("100% spending results in health score of 0", () => {
    const breakEven = [
      { type: "INCOME", amount: 1000, category: "OTHER" },
      { type: "EXPENSE", amount: 1000, category: "HOUSING" },
    ];
    const totals = calculateBudgetTotals(breakEven);
    assert.equal(totals.healthScore, 0);
  });

  test("zero expenses gives health score of 100", () => {
    const noSpend = [{ type: "INCOME", amount: 1000, category: "OTHER" }];
    const totals  = calculateBudgetTotals(noSpend);
    assert.equal(totals.healthScore, 100);
  });

  test("spending over income clamps to 0, not negative", () => {
    const overspend = [
      { type: "INCOME", amount: 500, category: "OTHER" },
      { type: "EXPENSE", amount: 2000, category: "HOUSING" },
    ];
    const totals = calculateBudgetTotals(overspend);
    assert.equal(totals.healthScore, 0);
    assert.equal(totals.balance, -1500);
  });

  test("byCategory groups expenses correctly", () => {
    const totals = calculateBudgetTotals(sampleEntries);
    assert.equal(totals.byCategory["HOUSING"], 1100);
    assert.equal(totals.byCategory["FOOD"], 400);
    assert.equal(totals.byCategory["OTHER"], undefined, "Income should not appear in byCategory");
  });

  test("empty entries produce zero totals and health score of 0 (no income = can't assess)", () => {
    const totals = calculateBudgetTotals([]);
    assert.equal(totals.income, 0);
    assert.equal(totals.expenses, 0);
    assert.equal(totals.healthScore, 0); // no income data → defaults to 0
  });
});

// ──────────────────────────────────────────────────────────────────

describe("3. Budget Entry Validation", () => {
  test("valid EXPENSE entry passes", () => {
    const r = validateBudgetEntry({ type: "EXPENSE", amount: 150, date: "2026-03-01" });
    assert.ok(r.valid);
  });

  test("valid INCOME entry passes", () => {
    const r = validateBudgetEntry({ type: "INCOME", amount: 3000, date: "2026-03-01" });
    assert.ok(r.valid);
  });

  test("invalid type is rejected", () => {
    const r = validateBudgetEntry({ type: "SAVINGS", amount: 100, date: "2026-03-01" });
    assert.equal(r.valid, false);
    assert.ok(r.error.includes("INCOME") || r.error.includes("EXPENSE"));
  });

  test("zero amount is rejected", () => {
    const r = validateBudgetEntry({ type: "EXPENSE", amount: 0, date: "2026-03-01" });
    assert.equal(r.valid, false);
  });

  test("negative amount is rejected", () => {
    const r = validateBudgetEntry({ type: "EXPENSE", amount: -50, date: "2026-03-01" });
    assert.equal(r.valid, false);
  });

  test("missing date is rejected", () => {
    const r = validateBudgetEntry({ type: "EXPENSE", amount: 100, date: "" });
    assert.equal(r.valid, false);
  });
});

// ──────────────────────────────────────────────────────────────────

describe("4. Portfolio Cost Averaging", () => {
  test("buying new position sets avgCost to purchase price", () => {
    const { totalShares, newAvgCost } = calculatePortfolioAvgCost(0, 0, 5, 200);
    assert.equal(totalShares, 5);
    assert.equal(newAvgCost, 200);
  });

  test("buying same price doubles shares, keeps avgCost", () => {
    const { totalShares, newAvgCost } = calculatePortfolioAvgCost(5, 200, 5, 200);
    assert.equal(totalShares, 10);
    assert.equal(newAvgCost, 200);
  });

  test("buying at lower price brings avgCost down", () => {
    const { totalShares, newAvgCost } = calculatePortfolioAvgCost(10, 200, 10, 100);
    assert.equal(totalShares, 20);
    assert.equal(newAvgCost, 150); // (10*200 + 10*100) / 20 = 150
  });

  test("buying at higher price brings avgCost up", () => {
    const { totalShares, newAvgCost } = calculatePortfolioAvgCost(5, 100, 5, 200);
    assert.equal(totalShares, 10);
    assert.equal(newAvgCost, 150); // (5*100 + 5*200) / 10 = 150
  });

  test("fractional shares compute correctly", () => {
    const { totalShares, newAvgCost } = calculatePortfolioAvgCost(2.5, 200, 2.5, 100);
    assert.equal(totalShares, 5);
    assert.equal(newAvgCost, 150);
  });
});

// ──────────────────────────────────────────────────────────────────

describe("5. Risk Score Calculation", () => {
  test("all 1s gives score of 1 (most conservative)", () => {
    assert.equal(calculateRiskScore([1, 1, 1, 1, 1]), 1);
  });

  test("all 5s gives score of 5 (most aggressive)", () => {
    assert.equal(calculateRiskScore([5, 5, 5, 5, 5]), 5);
  });

  test("average of 3s gives score of 3 (balanced)", () => {
    assert.equal(calculateRiskScore([3, 3, 3, 3, 3]), 3);
  });

  test("mixed answers are averaged and rounded", () => {
    assert.equal(calculateRiskScore([1, 2, 3, 4, 5]), 3); // avg = 3
  });

  test("score is always clamped between 1 and 5", () => {
    // Even with out-of-range inputs, score stays 1–5
    const score = calculateRiskScore([10, 10, 10]);
    assert.ok(score >= 1 && score <= 5);
  });

  test("empty array defaults to 2 (conservative beginner default)", () => {
    assert.equal(calculateRiskScore([]), 2);
  });
});

// ──────────────────────────────────────────────────────────────────

describe("6. JWT Token Logic", () => {
  const SECRET = "test-jwt-secret-that-is-long-enough-for-testing";

  test("signed token can be verified with same secret", () => {
    const token   = signTestToken("user-123", SECRET);
    const payload = verifyTestToken(token, SECRET);
    assert.equal(payload.userId, "user-123");
  });

  test("token has 3 parts separated by dots", () => {
    const token = signTestToken("user-abc", SECRET);
    assert.equal(token.split(".").length, 3);
  });

  test("tampered token fails verification", () => {
    const token  = signTestToken("user-123", SECRET);
    const parts  = token.split(".");
    const tampered = `${parts[0]}.${parts[1]}.fakesignature`;
    assert.throws(() => verifyTestToken(tampered, SECRET), /Invalid signature/);
  });

  test("token signed with different secret fails", () => {
    const token = signTestToken("user-123", SECRET);
    assert.throws(() => verifyTestToken(token, "different-secret"), /Invalid signature/);
  });

  test("two different userIds produce different tokens", () => {
    const t1 = signTestToken("user-001", SECRET);
    const t2 = signTestToken("user-002", SECRET);
    assert.notEqual(t1, t2);
  });

  test("userId is recoverable from token payload", () => {
    const userId  = "abc-def-ghi-123";
    const token   = signTestToken(userId, SECRET);
    const payload = verifyTestToken(token, SECRET);
    assert.equal(payload.userId, userId);
  });
});

// ──────────────────────────────────────────────────────────────────

describe("7. Claude Context Builder", () => {
  const profile = {
    buddyName: "Finn",
    riskScore: 2,
    goals: ["save_emergency_fund", "start_investing"],
  };

  test("context includes buddy name", () => {
    const ctx = buildUserContext(profile, null, []);
    assert.ok(ctx.includes("Finn"), "Context should include buddy name");
  });

  test("context includes risk score", () => {
    const ctx = buildUserContext(profile, null, []);
    assert.ok(ctx.includes("2/5"), "Context should include risk score");
  });

  test("context includes goals", () => {
    const ctx = buildUserContext(profile, null, []);
    assert.ok(ctx.includes("save_emergency_fund"), "Context should include goals");
  });

  test("empty holdings shows 'No holdings yet'", () => {
    const ctx = buildUserContext(profile, null, []);
    assert.ok(ctx.includes("No holdings yet"), "Context should note empty portfolio");
  });

  test("holdings are listed with ticker and shares", () => {
    const holdings = [{ ticker: "AAPL", shares: 5 }, { ticker: "VTI", shares: 3 }];
    const ctx = buildUserContext(profile, null, holdings);
    assert.ok(ctx.includes("AAPL x5 shares"), "Context should include AAPL holding");
    assert.ok(ctx.includes("VTI x3 shares"),  "Context should include VTI holding");
  });
});

// ──────────────────────────────────────────────────────────────────

describe("8. AI Response Validation", () => {
  test("valid insight JSON is accepted", () => {
    const raw = JSON.stringify({
      title: "Consider a bond ETF",
      body: "With your conservative risk score, adding BND could smooth out portfolio volatility.",
      riskLabel: "LOW",
      actionLabel: "Learn More",
    });
    assert.ok(validateInsightJSON(raw));
  });

  test("JSON wrapped in markdown fences is accepted", () => {
    const raw = '```json\n{"title":"T","body":"B","riskLabel":"LOW","actionLabel":"A"}\n```';
    assert.ok(validateInsightJSON(raw));
  });

  test("missing title fails validation", () => {
    const raw = JSON.stringify({ body: "B", riskLabel: "LOW", actionLabel: "A" });
    assert.equal(validateInsightJSON(raw), false);
  });

  test("missing riskLabel fails validation", () => {
    const raw = JSON.stringify({ title: "T", body: "B", actionLabel: "A" });
    assert.equal(validateInsightJSON(raw), false);
  });

  test("invalid JSON fails gracefully", () => {
    assert.equal(validateInsightJSON("not json at all"), false);
  });

  test("empty string fails gracefully", () => {
    assert.equal(validateInsightJSON(""), false);
  });
});

// ──────────────────────────────────────────────────────────────────

describe("9. End-to-End Data Flow Simulation", () => {
  test("full budget month simulation: add entries → compute totals → generate insight input", () => {
    const entries = [
      { type: "INCOME",  amount: 4000, category: "OTHER" },
      { type: "EXPENSE", amount: 1200, category: "HOUSING" },
      { type: "EXPENSE", amount: 500,  category: "FOOD" },
      { type: "EXPENSE", amount: 200,  category: "TRANSPORT" },
      { type: "EXPENSE", amount: 150,  category: "ENTERTAINMENT" },
      { type: "EXPENSE", amount: 400,  category: "SAVINGS" },
    ];

    const totals = calculateBudgetTotals(entries);

    // Verify totals
    assert.equal(totals.income, 4000);
    assert.equal(totals.expenses, 2450);
    assert.equal(totals.balance, 1550);
    assert.ok(totals.healthScore >= 40 && totals.healthScore <= 55,
      `Spending 61% of income should yield score ~48, got ${totals.healthScore}`);

    // Verify this data would make a sensible insight prompt
    const insightPrompt = `Monthly income: $${totals.income}. Expenses: ${JSON.stringify(totals.byCategory)}. Health: ${totals.healthScore}/100.`;
    assert.ok(insightPrompt.includes("4000"), "Prompt should contain income");
    assert.ok(insightPrompt.includes("HOUSING"), "Prompt should contain category");
  });

  test("full portfolio simulation: buy → hold → gain/loss calculation", () => {
    // Simulate buying 10 shares at $100
    const { totalShares: s1, newAvgCost: avg1 } = calculatePortfolioAvgCost(0, 0, 10, 100);
    assert.equal(s1, 10);
    assert.equal(avg1, 100);

    // Price goes up to $130 — gain/loss calculation
    const currentPrice = 130;
    const gainLoss     = (currentPrice - avg1) * s1;
    assert.equal(gainLoss, 300); // $30 gain × 10 shares

    // Buy 5 more at $130 — avg cost moves up
    const { totalShares: s2, newAvgCost: avg2 } = calculatePortfolioAvgCost(s1, avg1, 5, 130);
    assert.equal(s2, 15);
    assert.ok(avg2 > 100 && avg2 < 130, `New avg cost ${avg2} should be between 100 and 130`);
    // (10*100 + 5*130) / 15 = (1000 + 650) / 15 = 110
    assert.equal(avg2, 110);
  });

  test("onboarding → risk profile → context builder pipeline", () => {
    // Simulate onboarding quiz answers
    const quizAnswers = [2, 1, 3, 2, 1]; // conservative user
    const riskScore   = calculateRiskScore(quizAnswers);
    assert.equal(riskScore, 2, "Conservative answers should yield risk score 2");

    // Build profile
    const profile = {
      buddyName: "Penny",
      riskScore,
      goals: ["save_emergency_fund", "pay_off_debt"],
    };

    // Build context for Claude
    const context = buildUserContext(profile, { healthScore: 65 }, []);
    assert.ok(context.includes("Penny"));
    assert.ok(context.includes("2/5"));
    assert.ok(context.includes("save_emergency_fund"));
  });
});
