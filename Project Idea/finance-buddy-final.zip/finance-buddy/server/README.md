# Finance Buddy — Server Setup Guide

Follow these steps in order. Each step must complete successfully before moving to the next.

---

## Prerequisites

Make sure you have these installed before starting:

- **Node.js 18+** → https://nodejs.org (check: `node --version`)
- **PostgreSQL 15+** → https://postgresql.org/download (check: `psql --version`)
- **Git** → https://git-scm.com (check: `git --version`)

---

## Step 1 — Clone / open the project

If you downloaded the files directly, navigate into the server folder:

```bash
cd finance-buddy/server
```

---

## Step 2 — Install dependencies

```bash
npm install
```

This installs Express, Prisma, the Anthropic SDK, bcrypt, and JWT.

---

## Step 3 — Set up environment variables

Copy the example env file and fill in your values:

```bash
cp .env.example .env
```

Then open `.env` in any text editor and fill in:

| Variable | Where to get it |
|---|---|
| `DATABASE_URL` | Your local Postgres connection string |
| `JWT_SECRET` | Any long random string (32+ chars) |
| `ANTHROPIC_API_KEY` | console.anthropic.com |
| `ALPHA_VANTAGE_API_KEY` | alphavantage.co |

**Example DATABASE_URL for local Postgres:**
```
postgresql://postgres:yourpassword@localhost:5432/financebuddy
```

---

## Step 4 — Create the database

Open a terminal and run:

```bash
psql -U postgres -c "CREATE DATABASE financebuddy;"
```

If you set a different username, replace `postgres` with yours.

---

## Step 5 — Run Prisma migrations

This creates all 6 tables in your database:

```bash
npm run db:generate   # generates the Prisma client
npm run db:migrate    # runs the migration (name it "init" when prompted)
```

To visually inspect your database tables, run:

```bash
npm run db:studio
```

It opens a browser UI at http://localhost:5555

---

## Step 6 — Start the server

```bash
npm run dev
```

You should see:
```
🚀 Finance Buddy API running on http://localhost:3001
   Health check: http://localhost:3001/health
```

---

## Step 7 — Verify everything is working

Open a new terminal and test the health check:

```bash
curl http://localhost:3001/health
```

Expected response:
```json
{ "status": "ok", "service": "Finance Buddy API", ... }
```

Then test signup:

```bash
curl -X POST http://localhost:3001/api/v1/auth/signup \
  -H "Content-Type: application/json" \
  -d '{"email":"test@test.com","password":"password123","buddyName":"Finn","ageConfirmed":true}'
```

Expected response:
```json
{ "userId": "...", "buddyName": "Finn", "token": "...", "onboardingComplete": false }
```

If both of those work — **your backend is ready**. Move on to setting up the React frontend.

---

## Troubleshooting

**`ECONNREFUSED` on database** — PostgreSQL isn't running. Start it with:
- Mac: `brew services start postgresql`
- Windows: Start from Services or pgAdmin
- Linux: `sudo systemctl start postgresql`

**`P1001` from Prisma** — Wrong DATABASE_URL. Double-check the username, password, and database name.

**`401` on API calls** — JWT_SECRET is missing from `.env` or the token has expired.

**`429` from Alpha Vantage** — Free tier limit hit (25 calls/day). Wait until the next day or upgrade.
