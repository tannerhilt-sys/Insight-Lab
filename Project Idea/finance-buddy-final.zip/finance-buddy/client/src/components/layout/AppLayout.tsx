// components/layout/AppLayout.tsx
// Persistent sidebar + top bar layout for all protected pages

import { ReactNode } from "react";
import { NavLink, useNavigate } from "react-router-dom";
import { useAuthStore } from "../../stores/authStore";
import { useChatStore } from "../../stores/chatStore";

const NAV_ITEMS = [
  { to: "/dashboard",  label: "Dashboard",  icon: "🏠" },
  { to: "/budget",     label: "Budget",     icon: "💰" },
  { to: "/portfolio",  label: "Portfolio",  icon: "📈" },
  { to: "/learn",      label: "Learn",      icon: "📚" },
  { to: "/settings",   label: "Settings",   icon: "⚙️" },
];

export default function AppLayout({ children }: { children: ReactNode }) {
  const logout    = useAuthStore(s => s.logout);
  const openChat  = useChatStore(s => s.openChat);
  const navigate  = useNavigate();

  function handleLogout() {
    logout();
    navigate("/login");
  }

  return (
    <div className="min-h-screen bg-gray-50 flex">

      {/* ── Sidebar ── */}
      <aside className="w-60 bg-white border-r border-gray-100 flex flex-col shadow-sm fixed h-full z-10">
        {/* Logo */}
        <div className="px-6 py-5 border-b border-gray-100">
          <span className="text-xl font-extrabold text-blue-700 tracking-tight">Finance Buddy</span>
          <p className="text-xs text-gray-400 mt-0.5">Your AI financial companion</p>
        </div>

        {/* Nav */}
        <nav className="flex-1 px-3 py-4 space-y-1">
          {NAV_ITEMS.map(item => (
            <NavLink
              key={item.to}
              to={item.to}
              className={({ isActive }) =>
                `flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm font-medium transition-colors
                ${isActive
                  ? "bg-blue-50 text-blue-700"
                  : "text-gray-600 hover:bg-gray-50 hover:text-gray-900"}`
              }
            >
              <span className="text-lg">{item.icon}</span>
              {item.label}
            </NavLink>
          ))}
        </nav>

        {/* Chat button */}
        <div className="px-3 pb-4">
          <button
            onClick={openChat}
            className="w-full flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm font-medium
              bg-blue-600 text-white hover:bg-blue-700 transition-colors shadow-sm"
          >
            <span className="text-lg">💬</span>
            Ask my Buddy
          </button>
        </div>

        {/* User footer */}
        <div className="px-4 py-4 border-t border-gray-100">
          <button
            onClick={handleLogout}
            className="text-xs text-gray-400 hover:text-gray-600 transition-colors"
          >
            Sign out
          </button>
        </div>
      </aside>

      {/* ── Main content ── */}
      <main className="flex-1 ml-60 min-h-screen">
        <div className="max-w-5xl mx-auto px-8 py-8">
          {children}
        </div>
      </main>

    </div>
  );
}
