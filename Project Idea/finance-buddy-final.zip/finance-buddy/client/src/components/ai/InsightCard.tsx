// components/ai/InsightCard.tsx
// Renders a single AI-generated insight with accept / dismiss controls

import { useState } from "react";
import { api } from "../../lib/api";
import { Badge } from "../ui";

interface Insight {
  id: string;
  type: string;
  title: string;
  body: string;
  riskLabel?: "LOW" | "MEDIUM" | "HIGH";
  actionLabel?: string;
  status: string;
}

const RISK_VARIANT: Record<string, "green" | "amber" | "red"> = {
  LOW: "green", MEDIUM: "amber", HIGH: "red",
};
const TYPE_ICON: Record<string, string> = {
  BUDGET: "💰", PORTFOLIO: "📈", RECOMMENDATION: "💡", MARKET: "📰",
};

export default function InsightCard({ insight, onUpdate }: { insight: Insight; onUpdate: () => void }) {
  const [loading, setLoading] = useState<"accept" | "dismiss" | null>(null);

  async function handle(action: "accept" | "dismiss") {
    setLoading(action);
    try {
      await api.post(`/insights/${insight.id}/${action}`, {});
      onUpdate();
    } finally {
      setLoading(null);
    }
  }

  if (insight.status !== "PENDING") return null;

  return (
    <div className="bg-white border border-blue-100 rounded-2xl shadow-sm overflow-hidden">
      {/* Top accent bar */}
      <div className="h-1 bg-gradient-to-r from-blue-500 to-indigo-500" />

      <div className="p-5">
        {/* Header */}
        <div className="flex items-start justify-between gap-3 mb-3">
          <div className="flex items-center gap-2">
            <span className="text-xl">{TYPE_ICON[insight.type] || "💡"}</span>
            <span className="text-xs font-semibold text-gray-400 uppercase tracking-wide">
              {insight.type.toLowerCase()} insight
            </span>
          </div>
          {insight.riskLabel && (
            <Badge label={insight.riskLabel} variant={RISK_VARIANT[insight.riskLabel]} />
          )}
        </div>

        <h3 className="font-bold text-gray-900 text-base mb-2">{insight.title}</h3>
        <p className="text-sm text-gray-600 leading-relaxed mb-4">{insight.body}</p>

        {/* Actions */}
        <div className="flex gap-2">
          <button
            onClick={() => handle("accept")}
            disabled={loading !== null}
            className="flex-1 py-2 bg-blue-600 text-white text-sm font-semibold rounded-xl hover:bg-blue-700 disabled:opacity-50 transition-colors"
          >
            {loading === "accept" ? "..." : (insight.actionLabel || "Accept")}
          </button>
          <button
            onClick={() => handle("dismiss")}
            disabled={loading !== null}
            className="px-4 py-2 bg-gray-100 text-gray-600 text-sm font-semibold rounded-xl hover:bg-gray-200 disabled:opacity-50 transition-colors"
          >
            {loading === "dismiss" ? "..." : "Dismiss"}
          </button>
        </div>
      </div>
    </div>
  );
}
