// components/ai/ChatWidget.tsx
// Floating chat drawer — available on every protected screen

import { useState, useEffect, useRef } from "react";
import { useChatStore } from "../../stores/chatStore";
import { Spinner } from "../ui";

export default function ChatWidget() {
  const { isOpen, messages, suggestions, isStreaming, closeChat, sendMessage, loadSuggestions, clearHistory } = useChatStore();
  const [input, setInput]   = useState("");
  const bottomRef           = useRef<HTMLDivElement>(null);

  // Load suggestions when chat opens
  useEffect(() => {
    if (isOpen && suggestions.length === 0) loadSuggestions();
  }, [isOpen]);

  // Auto-scroll to latest message
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  async function handleSend(text?: string) {
    const msg = text || input.trim();
    if (!msg || isStreaming) return;
    setInput("");
    await sendMessage(msg);
  }

  if (!isOpen) return null;

  return (
    <>
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black/20 z-40 backdrop-blur-sm"
        onClick={closeChat}
      />

      {/* Drawer */}
      <div className="fixed right-0 top-0 h-full w-[420px] bg-white shadow-2xl z-50 flex flex-col">

        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100 bg-gradient-to-r from-blue-600 to-blue-500">
          <div>
            <h2 className="text-white font-bold text-base">Your Finance Buddy</h2>
            <p className="text-blue-100 text-xs">Ask me anything about your finances</p>
          </div>
          <div className="flex gap-2">
            <button
              onClick={clearHistory}
              title="Clear conversation"
              className="text-blue-200 hover:text-white text-xs transition-colors"
            >
              Clear
            </button>
            <button
              onClick={closeChat}
              className="text-blue-200 hover:text-white transition-colors text-xl leading-none"
            >
              ×
            </button>
          </div>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4">
          {messages.length === 0 && (
            <div className="text-center pt-8">
              <div className="text-5xl mb-3">💰</div>
              <p className="text-gray-500 text-sm font-medium">Hi! I'm your Finance Buddy.</p>
              <p className="text-gray-400 text-xs mt-1">Ask me anything about your money.</p>
            </div>
          )}

          {messages.map((msg, i) => (
            <div key={i} className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}>
              {msg.role === "assistant" && (
                <div className="w-7 h-7 rounded-full bg-blue-600 flex items-center justify-center text-white text-xs font-bold mr-2 mt-1 flex-shrink-0">
                  FB
                </div>
              )}
              <div
                className={`max-w-[78%] px-4 py-3 rounded-2xl text-sm leading-relaxed
                  ${msg.role === "user"
                    ? "bg-blue-600 text-white rounded-br-sm"
                    : "bg-gray-100 text-gray-800 rounded-bl-sm"}`}
              >
                {msg.content}
                {msg.streaming && (
                  <span className="inline-block w-1.5 h-4 bg-blue-400 ml-1 animate-pulse rounded-sm" />
                )}
              </div>
            </div>
          ))}
          <div ref={bottomRef} />
        </div>

        {/* Quick suggestions */}
        {messages.length === 0 && suggestions.length > 0 && (
          <div className="px-4 pb-3 space-y-2">
            <p className="text-xs text-gray-400 font-medium">Try asking:</p>
            <div className="flex flex-wrap gap-2">
              {suggestions.map((s, i) => (
                <button
                  key={i}
                  onClick={() => handleSend(s)}
                  className="text-xs bg-blue-50 text-blue-700 px-3 py-1.5 rounded-full hover:bg-blue-100 transition-colors border border-blue-100"
                >
                  {s}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Input */}
        <div className="px-4 py-4 border-t border-gray-100">
          <div className="flex gap-2 items-end">
            <textarea
              rows={2}
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); handleSend(); }}}
              placeholder="Ask about your budget, portfolio, or any finance topic..."
              className="flex-1 resize-none px-4 py-2.5 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 bg-gray-50"
            />
            <button
              onClick={() => handleSend()}
              disabled={!input.trim() || isStreaming}
              className="px-4 py-2.5 bg-blue-600 text-white rounded-xl hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex-shrink-0"
            >
              {isStreaming ? <Spinner size="sm" /> : "→"}
            </button>
          </div>
          <p className="text-xs text-gray-400 mt-2 text-center">
            Finance Buddy provides educational guidance only — not financial advice.
          </p>
        </div>
      </div>
    </>
  );
}
