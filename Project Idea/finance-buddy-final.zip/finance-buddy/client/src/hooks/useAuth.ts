// hooks/useAuth.ts
// Convenience hook — returns auth state and handles redirect
import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuthStore } from "../stores/authStore";

export function useAuth(redirectTo = "/login") {
  const { isAuthed, token, userId, hydrate } = useAuthStore();
  const navigate = useNavigate();

  useEffect(() => {
    hydrate();
  }, []);

  useEffect(() => {
    if (!isAuthed) {
      navigate(redirectTo, { replace: true });
    }
  }, [isAuthed, redirectTo, navigate]);

  return { isAuthed, token, userId };
}
