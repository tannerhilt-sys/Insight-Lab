// hooks/usePageTitle.ts
import { useEffect } from "react";

export function usePageTitle(title: string) {
  useEffect(() => {
    const prev = document.title;
    document.title = `${title} — Finance Buddy`;
    return () => { document.title = prev; };
  }, [title]);
}
