// pages/DashboardPage.tsx
import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { Card, StatCard, Spinner, Button, ProgressBar } from "../components/ui";
import AppLayout from "../components/layout/AppLayout";
import ChatWidget from "../components/ai/ChatWidget";
import InsightCard from "../components/ai/InsightCard";
import { useChatStore } from "../stores/chatStore";
import { useBudgetStore } from "../stores/budgetStore";
import { usePortfolioStore } from "../stores/portfolioStore";
import { useProfileStore } from "../stores/profileStore";

export default function DashboardPage() {
  const navigate = useNavigate();
  const openChat = useChatStore(s => s.openChat);

  const { profile, loading: profileLoading, fetchProfile } = useProfileStore();
  const { totals, goals, insight, loading: budgetLoading, fetchEntries, fetchGoals, fetchInsight } = useBudgetStore();
  const { holdings, totalValue, totalGainLoss, insights, loading: portLoading,
    fetchHoldings, fetchInsights, generateInsight, acceptInsight, dismissInsight } = usePortfolioStore();

  useEffect(() => {
    fetchProfile();
    fetchEntries();
    fetchGoals();
    fetchHoldings();
    fetchInsights();
  }, []);

  useEffect(() => {
    if (totals) fetchInsight();
  }, [totals]);

  const loading = profileLoading || budgetLoading || portLoading;
  const month   = new Date().toLocaleString("default", { month: "long", year: "numeric" });

  if (loading && !profile && !totals) {
    return (
      <AppLayout>
        <div className="flex items-center justify-center h-64"><Spinner size="lg" /></div>
        <ChatWidget />
      </AppLayout>
    );
  }

  if (!profileLoading && !profile) {
    return (
      <AppLayout>
        <div className="flex flex-col items-center justify-center h-64 text-center">
          <div className="text-5xl mb-4">👋</div>
          <p className="text-gray-500 mb-4">Let's set up your Finance Buddy profile first.</p>
          <Button onClick={() => navigate("/onboarding")}>Start Onboarding</Button>
        </div>
        <ChatWidget />
      </AppLayout>
    );
  }

  const balance = totals ? totals.income - totals.expenses : 0;
  const pendingInsights = insights.filter(i => i.status === "PENDING");

  return (
    <AppLayout>
      {/* Greeting */}
      <div className="mb-8">
        <h1 className="text-3xl font-extrabold text-gray-900">
          Hey there! Your buddy <span className="text-blue-600">{profile?.buddyName}</span> is ready 👋
        </h1>
        <p className="text-gray-500 mt-1">{month} — here's your financial snapshot.</p>
      </div>

      {/* Stats row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        <StatCard label="Monthly Income"  value={`$${(totals?.income || 0).toLocaleString()}`} sub="This month" color="green" />
        <StatCard label="Expenses"        value={`$${(totals?.expenses || 0).toLocaleString()}`} sub="This month" color="gray" />
        <StatCard label="Balance"         value={`$${balance.toLocaleString()}`} sub={balance >= 0 ? "Looking good!" : "Over budget"} color={balance >= 0 ? "blue" : "red"} />
        <StatCard label="Portfolio Value" value={holdings.length ? `$${totalValue.toLocaleString(undefined,{maximumFractionDigits:0})}` : "—"}
          sub={holdings.length ? `${holdings.length} holding${holdings.length !== 1 ? "s" : ""}` : "No holdings yet"} color="purple" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">

        {/* Left — 2/3 width */}
        <div className="lg:col-span-2 space-y-6">

          {/* AI Budget Insight */}
          {insight && (
            <Card>
              <div className="flex items-center gap-2 mb-3">
                <span className="text-xl">🤖</span>
                <h2 className="font-bold text-gray-900">Budget Insight from {profile?.buddyName}</h2>
              </div>
              <p className="text-sm text-gray-600 leading-relaxed">{insight}</p>
              <button onClick={() => navigate("/budget")} className="mt-3 text-sm text-blue-600 font-semibold hover:underline">
                View full budget →
              </button>
            </Card>
          )}

          {/* Savings Goals */}
          {goals.length > 0 && (
            <Card>
              <h2 className="font-bold text-gray-900 mb-4">Savings Goals</h2>
              <div className="space-y-4">
                {goals.map(g => {
                  const pct = Math.min(100, Math.round((g.currentAmount / g.targetAmount) * 100));
                  return (
                    <div key={g.id}>
                      <div className="flex justify-between text-sm mb-1.5">
                        <span className="font-medium text-gray-700">{g.label}</span>
                        <span className="text-gray-400">${Number(g.currentAmount).toLocaleString()} / ${Number(g.targetAmount).toLocaleString()}</span>
                      </div>
                      <ProgressBar value={g.currentAmount} max={g.targetAmount} />
                      <p className="text-xs text-gray-400 mt-1">{pct}% complete{g.deadline ? ` · Due ${new Date(g.deadline).toLocaleDateString()}` : ""}</p>
                    </div>
                  );
                })}
              </div>
            </Card>
          )}

          {/* Portfolio snapshot */}
          {holdings.length > 0 && (
            <Card>
              <div className="flex items-center justify-between mb-4">
                <h2 className="font-bold text-gray-900">Paper Portfolio</h2>
                <div className="flex items-center gap-3">
                  <span className={`text-sm font-semibold ${totalGainLoss >= 0 ? "text-green-600" : "text-red-500"}`}>
                    {totalGainLoss >= 0 ? "+" : ""}${totalGainLoss.toFixed(2)} total
                  </span>
                  <button onClick={() => navigate("/portfolio")} className="text-sm text-blue-600 font-semibold hover:underline">
                    View all →
                  </button>
                </div>
              </div>
              <div className="space-y-3">
                {holdings.slice(0, 4).map(h => (
                  <div key={h.id} className="flex items-center justify-between py-1">
                    <div>
                      <span className="font-bold text-gray-900 text-sm">{h.ticker}</span>
                      <span className="text-gray-400 text-xs ml-2">{h.shares} shares</span>
                      {h.stale && <span className="ml-2 text-xs text-amber-400">⚠ stale</span>}
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-semibold text-gray-900">
                        ${(h.currentValue || 0).toLocaleString(undefined, { maximumFractionDigits: 0 })}
                      </p>
                      <p className={`text-xs font-medium ${(h.gainLoss || 0) >= 0 ? "text-green-600" : "text-red-500"}`}>
                        {(h.gainLoss || 0) >= 0 ? "+" : ""}${(h.gainLoss || 0).toFixed(2)}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          )}
        </div>

        {/* Right — 1/3 width */}
        <div className="space-y-6">

          {/* Insight cards */}
          {pendingInsights.length > 0 ? (
            <div className="space-y-4">
              <h2 className="font-bold text-gray-900">💡 Insights for you</h2>
              {pendingInsights.slice(0, 2).map(ins => (
                <InsightCard key={ins.id} insight={ins} onUpdate={fetchInsights} />
              ))}
            </div>
          ) : (
            <Card>
              <h2 className="font-bold text-gray-900 mb-2">💡 Get an AI Insight</h2>
              <p className="text-sm text-gray-500 mb-4">
                Let {profile?.buddyName} analyse your profile and generate a personalised recommendation.
              </p>
              <Button fullWidth variant="secondary" onClick={generateInsight}>
                Generate Insight
              </Button>
            </Card>
          )}

          {/* Ask buddy */}
          <Card>
            <h2 className="font-bold text-gray-900 mb-2">Ask {profile?.buddyName}</h2>
            <p className="text-sm text-gray-500 mb-3">
              {profile?.buddyName} knows your budget, portfolio, and goals — ask anything.
            </p>
            <div className="space-y-1.5 mb-3">
              {["Why is my portfolio down?", "How much should I save?", "What is an ETF?"].map(q => (
                <button key={q} onClick={openChat}
                  className="w-full text-left text-sm text-blue-600 hover:text-blue-700 px-3 py-1.5 rounded-lg hover:bg-blue-50 transition-colors">
                  "{q}"
                </button>
              ))}
            </div>
            <Button fullWidth variant="primary" size="sm" onClick={openChat}>Open Chat</Button>
          </Card>

          {/* Risk profile */}
          {profile && (
            <Card>
              <h2 className="font-bold text-gray-900 mb-3">Your Risk Profile</h2>
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-blue-100 flex items-center justify-center text-blue-700 font-extrabold text-xl">
                  {profile.riskScore}
                </div>
                <div>
                  <p className="text-sm font-semibold text-gray-700">
                    {["","Very Conservative","Conservative","Balanced","Growth-Focused","Aggressive"][profile.riskScore]}
                  </p>
                  <p className="text-xs text-gray-400">Score {profile.riskScore} out of 5</p>
                </div>
              </div>
            </Card>
          )}
        </div>
      </div>

      <ChatWidget />
    </AppLayout>
  );
}
