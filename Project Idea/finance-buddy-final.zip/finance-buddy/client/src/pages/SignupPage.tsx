// pages/SignupPage.tsx
import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { useAuthStore } from "../stores/authStore";
import { Button, Input, Alert } from "../components/ui";

export default function SignupPage() {
  const [email, setEmail]       = useState("");
  const [password, setPassword] = useState("");
  const [ageConfirmed, setAge]  = useState(false);
  const [error, setError]       = useState("");
  const [loading, setLoading]   = useState(false);
  const signup                  = useAuthStore(s => s.signup);
  const navigate                = useNavigate();

  async function handleSubmit() {
    setError("");
    if (!email || !password)  { setError("Email and password are required."); return; }
    if (password.length < 8)  { setError("Password must be at least 8 characters."); return; }
    if (!ageConfirmed)        { setError("You must confirm you are 16 or older to create an account."); return; }
    setLoading(true);
    try {
      await signup(email, password, ageConfirmed);
      navigate("/onboarding");
    } catch (e: any) {
      setError(e.message || "Signup failed. Please try again.");
    } finally { setLoading(false); }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center px-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-extrabold text-blue-700 mb-2">Finance Buddy 💰</h1>
          <p className="text-gray-500 text-sm">Get started — it's free</p>
        </div>
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-8 space-y-5">
          <h2 className="text-xl font-bold text-gray-900">Create your account</h2>
          {error && <Alert message={error} />}
          <Input label="Email" type="email" value={email} onChange={setEmail} placeholder="you@example.com" required />
          <Input label="Password" type="password" value={password} onChange={setPassword} placeholder="Min. 8 characters" required />

          <label className="flex items-start gap-3 cursor-pointer">
            <input type="checkbox" checked={ageConfirmed} onChange={e => setAge(e.target.checked)}
              className="mt-0.5 w-4 h-4 text-blue-600 rounded border-gray-300 focus:ring-blue-500" />
            <span className="text-sm text-gray-600">
              I confirm I am <strong>16 years of age or older</strong> and agree to the Terms of Service.
              Finance Buddy provides educational guidance only and is not a licensed financial advisor.
            </span>
          </label>

          <Button type="submit" onClick={handleSubmit} loading={loading} fullWidth size="lg">Create Account</Button>
          <p className="text-center text-sm text-gray-500">
            Already have an account?{" "}
            <Link to="/login" className="text-blue-600 font-semibold hover:underline">Sign in</Link>
          </p>
        </div>
      </div>
    </div>
  );
}
