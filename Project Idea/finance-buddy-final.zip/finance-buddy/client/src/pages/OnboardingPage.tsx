// pages/OnboardingPage.tsx
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { api } from "../lib/api";
import { Button, Alert, Spinner } from "../components/ui";

const GOALS = [
  { id: "save_emergency_fund", label: "🛟 Build an Emergency Fund" },
  { id: "start_investing",     label: "📈 Start Investing" },
  { id: "save_for_college",    label: "🎓 Save for College" },
  { id: "pay_off_debt",        label: "💳 Pay Off Debt" },
  { id: "big_purchase",        label: "🛒 Save for a Big Purchase" },
  { id: "learn_finance",       label: "📚 Learn About Personal Finance" },
];

const RISK_LABELS = [
  "Very conservative — safety over growth",
  "Conservative — mostly safe, some growth",
  "Balanced — equal mix",
  "Growth-focused — I can handle some losses",
  "Aggressive — maximum growth, high risk OK",
];

const SAVINGS_OPTIONS = [
  { id: "NONE",         label: "I don't save regularly yet" },
  { id: "OCCASIONAL",  label: "I save occasionally" },
  { id: "REGULAR",     label: "I save most months" },
  { id: "DISCIPLINED", label: "I save every month without fail" },
];

type Step = "name" | "goals" | "risk" | "savings" | "summary";

export default function OnboardingPage() {
  const [step, setStep]             = useState<Step>("name");
  const [buddyName, setBuddyName]   = useState("");
  const [goals, setGoals]           = useState<string[]>([]);
  const [riskScore, setRisk]        = useState(2);
  const [savingsHabit, setSavings]  = useState("OCCASIONAL");
  const [investing, setInvesting]   = useState(true);
  const [summary, setSummary]       = useState("");
  const [error, setError]           = useState("");
  const [loading, setLoading]       = useState(false);
  const navigate                    = useNavigate();

  const STEPS: Step[] = ["name", "goals", "risk", "savings", "summary"];
  const stepIdx = STEPS.indexOf(step);
  const progress = Math.round((stepIdx / (STEPS.length - 1)) * 100);

  function toggleGoal(id: string) {
    setGoals(g => g.includes(id) ? g.filter(x => x !== id) : [...g, id]);
  }

  async function submit() {
    setLoading(true); setError("");
    try {
      const res: any = await api.post("/onboarding/profile", {
        buddyName, goals, knowledgeLevel: "BEGINNER",
        riskScore, savingsHabit, investingInterest: investing,
      });
      setSummary(res.aiSummary);
      setStep("summary");
    } catch (e: any) {
      setError(e.message || "Something went wrong. Please try again.");
    } finally { setLoading(false); }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50 flex items-center justify-center px-4 py-12">
      <div className="w-full max-w-lg">

        {step !== "summary" && (
          <div className="mb-6">
            <div className="flex justify-between text-xs text-gray-400 mb-2">
              <span>Setting up your profile</span>
              <span>Step {stepIdx + 1} of {STEPS.length - 1}</span>
            </div>
            <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
              <div className="h-2 bg-blue-600 rounded-full transition-all duration-500" style={{ width: `${progress}%` }} />
            </div>
          </div>
        )}

        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-8">
          {error && <div className="mb-4"><Alert message={error} /></div>}

          {step === "name" && (
            <div className="space-y-6">
              <div>
                <h2 className="text-2xl font-bold text-gray-900 mb-1">Welcome! Let's get started 👋</h2>
                <p className="text-gray-500 text-sm">Give your AI financial companion a name.</p>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Your buddy's name</label>
                <input value={buddyName} onChange={e => setBuddyName(e.target.value)}
                  placeholder="e.g. Finn, Max, Penny..."
                  className="w-full px-4 py-3 rounded-xl border border-gray-200 text-lg font-semibold focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
              <Button fullWidth size="lg" onClick={() => setStep("goals")} disabled={!buddyName.trim()}>
                Meet {buddyName || "your buddy"} →
              </Button>
            </div>
          )}

          {step === "goals" && (
            <div className="space-y-6">
              <div>
                <h2 className="text-2xl font-bold text-gray-900 mb-1">What are your goals?</h2>
                <p className="text-gray-500 text-sm">Select all that apply — {buddyName} will personalise everything around these.</p>
              </div>
              <div className="space-y-2">
                {GOALS.map(g => (
                  <button key={g.id} onClick={() => toggleGoal(g.id)}
                    className={`w-full text-left px-4 py-3 rounded-xl border text-sm font-medium transition-colors
                      ${goals.includes(g.id) ? "border-blue-500 bg-blue-50 text-blue-700" : "border-gray-200 hover:border-gray-300 text-gray-700"}`}>
                    {g.label}
                  </button>
                ))}
              </div>
              <div className="flex gap-3">
                <Button variant="secondary" onClick={() => setStep("name")}>Back</Button>
                <Button fullWidth onClick={() => setStep("risk")} disabled={goals.length === 0}>Next →</Button>
              </div>
            </div>
          )}

          {step === "risk" && (
            <div className="space-y-6">
              <div>
                <h2 className="text-2xl font-bold text-gray-900 mb-1">What's your risk tolerance?</h2>
                <p className="text-gray-500 text-sm">Helps {buddyName} tailor investment guidance to your comfort level.</p>
              </div>
              <div className="space-y-2">
                {RISK_LABELS.map((label, i) => (
                  <button key={i} onClick={() => setRisk(i + 1)}
                    className={`w-full text-left px-4 py-3 rounded-xl border text-sm font-medium transition-colors flex items-center gap-3
                      ${riskScore === i + 1 ? "border-blue-500 bg-blue-50 text-blue-700" : "border-gray-200 hover:border-gray-300 text-gray-700"}`}>
                    <span className="w-5 h-5 rounded-full border-2 flex items-center justify-center text-xs font-bold flex-shrink-0
                      {riskScore === i + 1 ? 'border-blue-600 bg-blue-600 text-white' : 'border-gray-300 text-gray-400'}">
                      {i + 1}
                    </span>
                    {label}
                  </button>
                ))}
              </div>
              <div className="flex gap-3">
                <Button variant="secondary" onClick={() => setStep("goals")}>Back</Button>
                <Button fullWidth onClick={() => setStep("savings")}>Next →</Button>
              </div>
            </div>
          )}

          {step === "savings" && (
            <div className="space-y-6">
              <div>
                <h2 className="text-2xl font-bold text-gray-900 mb-1">How do you save right now?</h2>
                <p className="text-gray-500 text-sm">Be honest — {buddyName} won't judge!</p>
              </div>
              <div className="space-y-2">
                {SAVINGS_OPTIONS.map(o => (
                  <button key={o.id} onClick={() => setSavings(o.id)}
                    className={`w-full text-left px-4 py-3 rounded-xl border text-sm font-medium transition-colors
                      ${savingsHabit === o.id ? "border-blue-500 bg-blue-50 text-blue-700" : "border-gray-200 hover:border-gray-300 text-gray-700"}`}>
                    {o.label}
                  </button>
                ))}
              </div>
              <div>
                <p className="text-sm font-medium text-gray-700 mb-2">Interested in investing?</p>
                <div className="flex gap-3">
                  {[true, false].map(v => (
                    <button key={String(v)} onClick={() => setInvesting(v)}
                      className={`flex-1 py-2.5 rounded-xl border text-sm font-semibold transition-colors
                        ${investing === v ? "border-blue-500 bg-blue-50 text-blue-700" : "border-gray-200 text-gray-600 hover:border-gray-300"}`}>
                      {v ? "Yes, definitely" : "Not right now"}
                    </button>
                  ))}
                </div>
              </div>
              <div className="flex gap-3">
                <Button variant="secondary" onClick={() => setStep("risk")}>Back</Button>
                <Button fullWidth loading={loading} onClick={submit}>Build my profile →</Button>
              </div>
            </div>
          )}

          {step === "summary" && (
            <div className="space-y-6 text-center">
              <div className="text-5xl mb-3">🎉</div>
              <h2 className="text-2xl font-bold text-gray-900">Meet {buddyName}!</h2>
              <p className="text-gray-500 text-sm">Here's your personalised financial profile:</p>
              {loading
                ? <div className="flex justify-center py-8"><Spinner size="lg" /></div>
                : <div className="bg-blue-50 border border-blue-100 rounded-2xl p-5 text-left">
                    <p className="text-sm text-gray-700 leading-relaxed whitespace-pre-wrap">{summary}</p>
                  </div>
              }
              <Button fullWidth size="lg" onClick={() => navigate("/dashboard")}>
                Go to my dashboard →
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
