// pages/BudgetPage.tsx
import { useState, useEffect } from "react";
import { Card, Button, Input, Alert, Spinner } from "../components/ui";
import AppLayout from "../components/layout/AppLayout";
import ChatWidget from "../components/ai/ChatWidget";
import { useBudgetStore } from "../stores/budgetStore";
import type { EntryType, Category } from "../types";

const CATEGORIES: Category[] = ["HOUSING","FOOD","TRANSPORT","ENTERTAINMENT","SAVINGS","OTHER"];
const CAT_ICONS: Record<Category, string> = {
  HOUSING:"🏠", FOOD:"🍔", TRANSPORT:"🚗", ENTERTAINMENT:"🎬", SAVINGS:"💰", OTHER:"📦"
};

export default function BudgetPage() {
  const { entries, totals, goals, insight, insightLoading, loading,
    fetchEntries, fetchGoals, fetchInsight, addEntry, deleteEntry, addGoal } = useBudgetStore();

  const [showForm, setShowForm]   = useState(false);
  const [showGoal, setShowGoal]   = useState(false);
  const [error, setError]         = useState("");
  const [saving, setSaving]       = useState(false);

  // Entry form
  const [type, setType]           = useState<EntryType>("EXPENSE");
  const [amount, setAmount]       = useState("");
  const [category, setCategory]   = useState<Category>("OTHER");
  const [description, setDesc]    = useState("");
  const [date, setDate]           = useState(new Date().toISOString().split("T")[0]);

  // Goal form
  const [goalLabel, setGoalLabel]   = useState("");
  const [goalAmount, setGoalAmount] = useState("");
  const [goalDeadline, setGoalDL]   = useState("");
  const [goalSaving, setGoalSaving] = useState(false);

  useEffect(() => {
    fetchEntries();
    fetchGoals();
  }, []);

  async function handleAddEntry() {
    setError(""); setSaving(true);
    try {
      if (!amount || isNaN(Number(amount)) || Number(amount) <= 0) {
        setError("Please enter a valid amount greater than 0."); return;
      }
      await addEntry({ type, amount: Number(amount), category, description: description || undefined, date });
      setAmount(""); setDesc(""); setShowForm(false);
      fetchInsight();
    } catch (e: any) { setError(e.message);
    } finally { setSaving(false); }
  }

  async function handleAddGoal() {
    setGoalSaving(true);
    try {
      await addGoal(goalLabel, Number(goalAmount), goalDeadline || undefined);
      setGoalLabel(""); setGoalAmount(""); setGoalDL(""); setShowGoal(false);
    } finally { setGoalSaving(false); }
  }

  const healthColor = !totals ? "gray"
    : totals.healthScore >= 70 ? "green"
    : totals.healthScore >= 40 ? "amber" : "red";

  return (
    <AppLayout>
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-extrabold text-gray-900">Budget Tracker</h1>
          <p className="text-gray-500 text-sm mt-1">
            {new Date().toLocaleString("default", { month: "long", year: "numeric" })}
          </p>
        </div>
        <div className="flex gap-2">
          <Button variant="secondary" onClick={() => setShowGoal(!showGoal)}>+ Goal</Button>
          <Button onClick={() => setShowForm(!showForm)}>+ Transaction</Button>
        </div>
      </div>

      {/* Stats */}
      {totals && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <div className="bg-green-50 border border-green-100 rounded-2xl p-4">
            <p className="text-xs font-semibold text-green-500 uppercase tracking-wide mb-1">Income</p>
            <p className="text-2xl font-bold text-green-700">${totals.income.toLocaleString()}</p>
          </div>
          <div className="bg-red-50 border border-red-100 rounded-2xl p-4">
            <p className="text-xs font-semibold text-red-400 uppercase tracking-wide mb-1">Expenses</p>
            <p className="text-2xl font-bold text-red-600">${totals.expenses.toLocaleString()}</p>
          </div>
          <div className={`${totals.balance >= 0 ? "bg-blue-50 border-blue-100" : "bg-red-50 border-red-100"} border rounded-2xl p-4`}>
            <p className="text-xs font-semibold text-gray-400 uppercase tracking-wide mb-1">Balance</p>
            <p className={`text-2xl font-bold ${totals.balance >= 0 ? "text-blue-700" : "text-red-600"}`}>
              ${totals.balance.toLocaleString()}
            </p>
          </div>
          <div className="bg-white border border-gray-100 rounded-2xl p-4">
            <p className="text-xs font-semibold text-gray-400 uppercase tracking-wide mb-1">Health</p>
            <p className={`text-2xl font-bold text-${healthColor}-600`}>
              {totals.healthScore}<span className="text-sm text-gray-400 font-normal">/100</span>
            </p>
          </div>
        </div>
      )}

      {/* Add Goal Form */}
      {showGoal && (
        <Card className="mb-4">
          <h3 className="font-bold text-gray-900 mb-4">Add a Savings Goal</h3>
          <div className="grid grid-cols-3 gap-4 mb-4">
            <Input label="Goal Name" value={goalLabel} onChange={setGoalLabel} placeholder="e.g. Emergency Fund" required />
            <Input label="Target ($)" type="number" value={goalAmount} onChange={setGoalAmount} placeholder="5000" required />
            <Input label="Deadline (optional)" type="date" value={goalDeadline} onChange={setGoalDL} />
          </div>
          <div className="flex gap-3">
            <Button variant="secondary" onClick={() => setShowGoal(false)}>Cancel</Button>
            <Button loading={goalSaving} onClick={handleAddGoal} disabled={!goalLabel || !goalAmount}>Save Goal</Button>
          </div>
        </Card>
      )}

      {/* Add Entry Form */}
      {showForm && (
        <Card className="mb-6">
          <h3 className="font-bold text-gray-900 mb-4">Add a Transaction</h3>
          {error && <div className="mb-3"><Alert message={error} /></div>}
          <div className="grid grid-cols-2 gap-4 mb-4">
            <div>
              <p className="text-sm font-medium text-gray-700 mb-1">Type</p>
              <div className="flex gap-2">
                {(["EXPENSE","INCOME"] as EntryType[]).map(t => (
                  <button key={t} onClick={() => setType(t)}
                    className={`flex-1 py-2 rounded-xl border text-sm font-semibold transition-colors
                      ${type === t ? (t === "INCOME" ? "border-green-500 bg-green-50 text-green-700" : "border-red-400 bg-red-50 text-red-600")
                        : "border-gray-200 text-gray-600 hover:border-gray-300"}`}>
                    {t === "INCOME" ? "💵 Income" : "💸 Expense"}
                  </button>
                ))}
              </div>
            </div>
            <Input label="Amount ($)" type="number" value={amount} onChange={setAmount} placeholder="0.00" required />
          </div>
          <div className="grid grid-cols-2 gap-4 mb-4">
            <div>
              <p className="text-sm font-medium text-gray-700 mb-1">Category</p>
              <select value={category} onChange={e => setCategory(e.target.value as Category)}
                className="w-full px-3 py-2.5 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white">
                {CATEGORIES.map(c => <option key={c} value={c}>{CAT_ICONS[c]} {c}</option>)}
              </select>
            </div>
            <Input label="Date" type="date" value={date} onChange={setDate} required />
          </div>
          <Input label="Description (optional)" value={description} onChange={setDesc} placeholder="e.g. Monthly rent" />
          <div className="flex gap-3 mt-4">
            <Button variant="secondary" onClick={() => { setShowForm(false); setError(""); }}>Cancel</Button>
            <Button fullWidth loading={saving} onClick={handleAddEntry}>Save Transaction</Button>
          </div>
        </Card>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">

        {/* Transactions */}
        <div className="lg:col-span-2">
          <Card>
            <h2 className="font-bold text-gray-900 mb-4">Transactions</h2>
            {loading ? (
              <div className="flex justify-center py-8"><Spinner /></div>
            ) : entries.length === 0 ? (
              <div className="text-center py-10">
                <p className="text-gray-400 text-sm">No transactions yet.</p>
                <button onClick={() => setShowForm(true)} className="mt-2 text-sm text-blue-600 font-semibold hover:underline">
                  Add your first one →
                </button>
              </div>
            ) : (
              <div className="divide-y divide-gray-50">
                {entries.map(e => (
                  <div key={e.id} className="flex items-center justify-between py-3">
                    <div className="flex items-center gap-3">
                      <span className="text-xl">{CAT_ICONS[e.category] || "📦"}</span>
                      <div>
                        <p className="text-sm font-medium text-gray-800">{e.description || e.category}</p>
                        <p className="text-xs text-gray-400">{new Date(e.date).toLocaleDateString()}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <span className={`text-sm font-bold ${e.type === "INCOME" ? "text-green-600" : "text-red-500"}`}>
                        {e.type === "INCOME" ? "+" : "−"}${Number(e.amount).toLocaleString()}
                      </span>
                      <button onClick={() => deleteEntry(e.id)} className="text-gray-300 hover:text-red-400 transition-colors text-sm">✕</button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </Card>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">

          {/* AI Insight */}
          <Card>
            <div className="flex items-center justify-between mb-3">
              <h2 className="font-bold text-gray-900">🤖 AI Insight</h2>
              <button onClick={fetchInsight} className="text-xs text-blue-600 hover:underline font-semibold">Refresh</button>
            </div>
            {insightLoading ? (
              <div className="flex justify-center py-4"><Spinner /></div>
            ) : insight ? (
              <p className="text-sm text-gray-600 leading-relaxed">{insight}</p>
            ) : (
              <button onClick={fetchInsight}
                className="w-full py-4 border-2 border-dashed border-blue-200 rounded-xl text-sm text-blue-500 hover:border-blue-400 transition-colors">
                Get AI budget analysis →
              </button>
            )}
          </Card>

          {/* Savings Goals */}
          {goals.length > 0 && (
            <Card>
              <h2 className="font-bold text-gray-900 mb-4">Savings Goals</h2>
              <div className="space-y-4">
                {goals.map(g => {
                  const pct = Math.min(100, Math.round((Number(g.currentAmount) / Number(g.targetAmount)) * 100));
                  return (
                    <div key={g.id}>
                      <div className="flex justify-between text-xs mb-1">
                        <span className="font-medium text-gray-600">{g.label}</span>
                        <span className="text-gray-400">{pct}%</span>
                      </div>
                      <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                        <div className="h-2 bg-blue-500 rounded-full transition-all duration-500" style={{ width: `${pct}%` }} />
                      </div>
                      <p className="text-xs text-gray-400 mt-1">
                        ${Number(g.currentAmount).toLocaleString()} of ${Number(g.targetAmount).toLocaleString()}
                      </p>
                    </div>
                  );
                })}
              </div>
            </Card>
          )}

          {/* Category breakdown */}
          {totals?.byCategory && Object.keys(totals.byCategory).length > 0 && (
            <Card>
              <h2 className="font-bold text-gray-900 mb-4">Spending by Category</h2>
              <div className="space-y-3">
                {Object.entries(totals.byCategory)
                  .sort(([,a],[,b]) => (b as number) - (a as number))
                  .map(([cat, amt]) => {
                    const pct = totals.expenses > 0 ? Math.round(((amt as number) / totals.expenses) * 100) : 0;
                    return (
                      <div key={cat}>
                        <div className="flex justify-between text-xs mb-1">
                          <span className="font-medium text-gray-600">{CAT_ICONS[cat as Category] || "📦"} {cat}</span>
                          <span className="text-gray-400">${(amt as number).toLocaleString()} ({pct}%)</span>
                        </div>
                        <div className="h-1.5 bg-gray-100 rounded-full overflow-hidden">
                          <div className="h-1.5 bg-blue-500 rounded-full" style={{ width: `${pct}%` }} />
                        </div>
                      </div>
                    );
                  })}
              </div>
            </Card>
          )}
        </div>
      </div>

      <ChatWidget />
    </AppLayout>
  );
}
