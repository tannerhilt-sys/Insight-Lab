// pages/LoginPage.tsx
import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { useAuthStore } from "../stores/authStore";
import { Button, Input, Alert } from "../components/ui";

export default function LoginPage() {
  const [email, setEmail]       = useState("");
  const [password, setPassword] = useState("");
  const [error, setError]       = useState("");
  const [loading, setLoading]   = useState(false);
  const login                   = useAuthStore(s => s.login);
  const navigate                = useNavigate();

  async function handleSubmit() {
    setError("");
    if (!email || !password) { setError("Please enter your email and password."); return; }
    setLoading(true);
    try {
      await login(email, password);
      navigate("/dashboard");
    } catch (e: any) {
      setError(e.message || "Login failed. Check your credentials and try again.");
    } finally { setLoading(false); }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center px-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-extrabold text-blue-700 mb-2">Finance Buddy 💰</h1>
          <p className="text-gray-500 text-sm">Your AI-powered financial companion</p>
        </div>
        <div className="bg-white rounded-2xl shadow-sm border border-gray-100 p-8 space-y-5">
          <h2 className="text-xl font-bold text-gray-900">Welcome back</h2>
          {error && <Alert message={error} />}
          <Input label="Email" type="email" value={email} onChange={setEmail} placeholder="you@example.com" required />
          <Input label="Password" type="password" value={password} onChange={setPassword} placeholder="••••••••" required />
          <Button type="submit" onClick={handleSubmit} loading={loading} fullWidth size="lg">Sign In</Button>
          <p className="text-center text-sm text-gray-500">
            Don't have an account?{" "}
            <Link to="/signup" className="text-blue-600 font-semibold hover:underline">Sign up free</Link>
          </p>
        </div>
        <p className="text-center text-xs text-gray-400 mt-6">
          Demo: demo@financebuddy.dev / password123
        </p>
      </div>
    </div>
  );
}
