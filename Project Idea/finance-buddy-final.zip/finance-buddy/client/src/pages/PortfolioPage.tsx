// pages/PortfolioPage.tsx
import { useState, useEffect } from "react";
import { api } from "../lib/api";
import { Card, Button, Spinner, Alert, Badge } from "../components/ui";
import AppLayout from "../components/layout/AppLayout";
import ChatWidget from "../components/ai/ChatWidget";

export default function PortfolioPage() {
  const [holdings, setHoldings]     = useState<any[]>([]);
  const [watchlist, setWatchlist]   = useState<any[]>([]);
  const [totalValue, setTotalValue] = useState(0);
  const [totalGL, setTotalGL]       = useState(0);
  const [loading, setLoading]       = useState(true);
  const [searchQ, setSearchQ]       = useState("");
  const [searchRes, setSearchRes]   = useState<any[]>([]);
  const [searching, setSearching]   = useState(false);
  const [explanation, setExp]       = useState<{ticker:string; text:string} | null>(null);
  const [expLoading, setExpL]       = useState(false);
  const [buyModal, setBuyModal]     = useState<any>(null);
  const [buyShares, setBuyShares]   = useState("");
  const [buying, setBuying]         = useState(false);
  const [error, setError]           = useState("");

  useEffect(() => { load(); }, []);

  async function load() {
    setLoading(true);
    try {
      const [port, wl] = await Promise.allSettled([
        api.get<any>("/portfolio/holdings"),
        api.get<any>("/portfolio/watchlist"),
      ]);
      if (port.status === "fulfilled") {
        setHoldings(port.value.holdings || []);
        setTotalValue(port.value.totalValue || 0);
        setTotalGL(port.value.totalGainLoss || 0);
      }
      if (wl.status === "fulfilled") setWatchlist(wl.value.watchlist || []);
    } finally { setLoading(false); }
  }

  async function search() {
    if (!searchQ.trim()) return;
    setSearching(true);
    try {
      const res = await api.get<any>(`/market/search?q=${encodeURIComponent(searchQ)}`);
      setSearchRes(res.results || []);
    } finally { setSearching(false); }
  }

  async function addToWatchlist(ticker: string) {
    await api.post("/portfolio/watchlist", { ticker });
    setSearchRes([]); setSearchQ(""); await load();
  }

  async function removeFromWatchlist(ticker: string) {
    await api.delete(`/portfolio/watchlist/${ticker}`);
    await load();
  }

  async function explain(ticker: string) {
    setExpL(true); setExp(null);
    try {
      const res = await api.get<any>(`/portfolio/explain/${ticker}`);
      setExp({ ticker, text: res.explanation });
    } finally { setExpL(false); }
  }

  async function buy() {
    if (!buyModal || !buyShares || Number(buyShares) <= 0) return;
    setBuying(true); setError("");
    try {
      await api.post("/portfolio/buy", { ticker: buyModal.ticker, shares: Number(buyShares) });
      setBuyModal(null); setBuyShares("");
      await load();
    } catch (e: any) { setError(e.message);
    } finally { setBuying(false); }
  }

  async function sell(ticker: string) {
    await api.post("/portfolio/sell", { ticker, shares: 1 });
    await load();
  }

  return (
    <AppLayout>
      <div className="mb-6">
        <h1 className="text-3xl font-extrabold text-gray-900">Paper Portfolio</h1>
        <p className="text-gray-500 text-sm mt-1">Simulated investing — no real money involved.</p>
      </div>

      {/* Portfolio summary */}
      <div className="grid grid-cols-2 gap-4 mb-6">
        <div className="bg-white border border-gray-100 rounded-2xl shadow-sm p-5">
          <p className="text-xs font-semibold text-gray-400 uppercase tracking-wide mb-1">Total Value</p>
          <p className="text-2xl font-bold text-blue-700">${totalValue.toLocaleString(undefined,{maximumFractionDigits:2})}</p>
        </div>
        <div className={`border rounded-2xl shadow-sm p-5 ${totalGL >= 0 ? "bg-green-50 border-green-100" : "bg-red-50 border-red-100"}`}>
          <p className="text-xs font-semibold text-gray-400 uppercase tracking-wide mb-1">Total Gain / Loss</p>
          <p className={`text-2xl font-bold ${totalGL >= 0 ? "text-green-600" : "text-red-600"}`}>
            {totalGL >= 0 ? "+" : ""}${totalGL.toFixed(2)}
          </p>
        </div>
      </div>

      {/* Search */}
      <Card className="mb-6">
        <h2 className="font-bold text-gray-900 mb-3">Search & Add Stocks</h2>
        <div className="flex gap-2 mb-3">
          <input value={searchQ} onChange={e => setSearchQ(e.target.value)}
            onKeyDown={e => e.key === "Enter" && search()}
            placeholder="Search by ticker or company name..."
            className="flex-1 px-4 py-2.5 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          <Button onClick={search} loading={searching}>Search</Button>
        </div>
        {searchRes.length > 0 && (
          <div className="space-y-2">
            {searchRes.map((r: any) => (
              <div key={r.ticker} className="flex items-center justify-between p-3 rounded-xl bg-gray-50 border border-gray-100">
                <div>
                  <span className="font-bold text-gray-900 text-sm">{r.ticker}</span>
                  <span className="text-gray-500 text-xs ml-2">{r.name}</span>
                </div>
                <div className="flex gap-2">
                  <Button size="sm" variant="secondary" onClick={() => setBuyModal(r)}>Buy</Button>
                  <Button size="sm" variant="ghost" onClick={() => addToWatchlist(r.ticker)}>+ Watchlist</Button>
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Holdings */}
        <Card>
          <h2 className="font-bold text-gray-900 mb-4">My Holdings</h2>
          {loading ? <Spinner /> : holdings.length === 0
            ? <p className="text-gray-400 text-sm text-center py-6">No holdings yet. Search for a stock and simulate a buy!</p>
            : (
              <div className="space-y-3">
                {holdings.map((h: any) => (
                  <div key={h.id} className="p-3 rounded-xl border border-gray-100 bg-gray-50">
                    <div className="flex items-start justify-between mb-2">
                      <div>
                        <span className="font-bold text-gray-900">{h.ticker}</span>
                        {h.stale && <span className="ml-2 text-xs text-amber-500">⚠ stale price</span>}
                        <p className="text-xs text-gray-400">{h.companyName}</p>
                      </div>
                      <span className={`text-sm font-bold ${(h.gainLoss||0) >= 0 ? "text-green-600":"text-red-500"}`}>
                        {(h.gainLoss||0) >= 0 ? "+" : ""}${(h.gainLoss||0).toFixed(2)}
                      </span>
                    </div>
                    <div className="flex items-center justify-between text-xs text-gray-500">
                      <span>{h.shares} shares @ ${Number(h.avgCost).toFixed(2)} avg</span>
                      <span>Now: ${(h.currentPrice||Number(h.avgCost)).toFixed(2)}</span>
                    </div>
                    <div className="flex gap-2 mt-2">
                      <button onClick={() => explain(h.ticker)} className="text-xs text-blue-600 hover:underline font-semibold">Explain</button>
                      <button onClick={() => sell(h.ticker)} className="text-xs text-red-500 hover:underline font-semibold">Sell 1</button>
                    </div>
                  </div>
                ))}
              </div>
            )
          }
        </Card>

        {/* Watchlist */}
        <Card>
          <h2 className="font-bold text-gray-900 mb-4">Watchlist</h2>
          {watchlist.length === 0
            ? <p className="text-gray-400 text-sm text-center py-6">Add stocks to your watchlist to track them.</p>
            : (
              <div className="space-y-3">
                {watchlist.map((w: any) => (
                  <div key={w.ticker} className="flex items-center justify-between p-3 rounded-xl border border-gray-100">
                    <div>
                      <span className="font-bold text-gray-900 text-sm">{w.ticker}</span>
                      <p className="text-xs text-gray-400">${(w.currentPrice||0).toFixed(2)}</p>
                    </div>
                    <div className="flex gap-2 items-center">
                      <span className={`text-xs font-semibold ${Number(w.changePercent||0) >= 0 ? "text-green-600":"text-red-500"}`}>
                        {Number(w.changePercent||0) >= 0 ? "▲":"▼"} {Math.abs(Number(w.changePercent||0)).toFixed(2)}%
                      </span>
                      <button onClick={() => setBuyModal(w)} className="text-xs text-blue-600 hover:underline font-semibold">Buy</button>
                      <button onClick={() => removeFromWatchlist(w.ticker)} className="text-gray-300 hover:text-red-400 text-xs">✕</button>
                    </div>
                  </div>
                ))}
              </div>
            )
          }
        </Card>
      </div>

      {/* AI Explanation panel */}
      {(expLoading || explanation) && (
        <Card className="mt-6">
          <h2 className="font-bold text-gray-900 mb-3">🤖 {explanation?.ticker} — Plain-English Explanation</h2>
          {expLoading ? <Spinner /> : <p className="text-sm text-gray-600 leading-relaxed whitespace-pre-wrap">{explanation?.text}</p>}
        </Card>
      )}

      {/* Buy modal */}
      {buyModal && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center px-4">
          <div className="bg-white rounded-2xl shadow-2xl w-full max-w-sm p-6">
            <h3 className="font-bold text-gray-900 text-lg mb-1">Simulate Buy — {buyModal.ticker}</h3>
            <p className="text-gray-500 text-sm mb-4">This is a paper trade. No real money is used.</p>
            {error && <div className="mb-3"><Alert message={error} /></div>}
            <div className="mb-4">
              <label className="text-sm font-medium text-gray-700 mb-1 block">Number of shares</label>
              <input type="number" min="1" value={buyShares} onChange={e => setBuyShares(e.target.value)}
                placeholder="e.g. 5"
                className="w-full px-4 py-2.5 rounded-xl border border-gray-200 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div className="flex gap-3">
              <Button variant="secondary" fullWidth onClick={() => {setBuyModal(null);setError("");}}>Cancel</Button>
              <Button fullWidth loading={buying} onClick={buy}>Confirm Buy</Button>
            </div>
          </div>
        </div>
      )}

      <ChatWidget />
    </AppLayout>
  );
}
