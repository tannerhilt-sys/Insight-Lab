// pages/LearnPage.tsx
import { useState } from "react";
import { api } from "../lib/api";
import { Card, Button, Spinner, Badge } from "../components/ui";
import AppLayout from "../components/layout/AppLayout";
import ChatWidget from "../components/ai/ChatWidget";

const LESSONS = [
  {
    id: "compound_interest",
    title: "Compound Interest",
    emoji: "📈",
    tagline: "Why starting early matters more than starting big",
    difficulty: "Beginner",
    prompt: "Explain compound interest to a 16-year-old beginner in plain language. Include a simple real-world example with numbers showing why starting early matters. End with one actionable tip.",
  },
  {
    id: "etfs",
    title: "What is an ETF?",
    emoji: "🗂️",
    tagline: "The beginner-friendly way to invest in many stocks at once",
    difficulty: "Beginner",
    prompt: "Explain ETFs (Exchange-Traded Funds) to a complete beginner. Cover what they are, why they're popular for beginners, and how they compare to buying individual stocks. Use plain language and a relatable analogy.",
  },
  {
    id: "diversification",
    title: "Diversification",
    emoji: "🥗",
    tagline: "Don't put all your eggs in one basket — here's why",
    difficulty: "Beginner",
    prompt: "Explain diversification to a beginner investor. Use a simple analogy, explain why it reduces risk, and give a practical example of a diversified vs non-diversified portfolio.",
  },
  {
    id: "risk_vs_reward",
    title: "Risk vs. Reward",
    emoji: "⚖️",
    tagline: "Understanding the fundamental trade-off in investing",
    difficulty: "Beginner",
    prompt: "Explain the risk vs reward trade-off in investing to a beginner. Cover what investment risk means, why higher potential reward usually means higher risk, and how to think about your own risk tolerance.",
  },
  {
    id: "budgeting_50_30_20",
    title: "The 50/30/20 Budget Rule",
    emoji: "💰",
    tagline: "A simple framework to manage your money",
    difficulty: "Beginner",
    prompt: "Explain the 50/30/20 budgeting rule to a beginner. Describe what each percentage covers, give an example with a real income number, and explain when this rule works well and when it might need adjusting.",
  },
  {
    id: "emergency_fund",
    title: "Emergency Funds",
    emoji: "🛟",
    tagline: "Why your first savings goal should be a safety net",
    difficulty: "Beginner",
    prompt: "Explain what an emergency fund is and why it should be a beginner's first savings priority. Cover how much to save, where to keep it, and what counts as a real emergency vs a want.",
  },
  {
    id: "pe_ratio",
    title: "What is a P/E Ratio?",
    emoji: "🔢",
    tagline: "A key number for evaluating if a stock is expensive",
    difficulty: "Intermediate",
    prompt: "Explain the Price-to-Earnings (P/E) ratio to a beginner who has just started investing. Cover what it means, how to read it, whether a high or low P/E is better, and what its limitations are.",
  },
];

export default function LearnPage() {
  const [activeLesson, setActiveLesson] = useState<string | null>(null);
  const [lessonContent, setContent]     = useState<Record<string, string>>({});
  const [loading, setLoading]           = useState<string | null>(null);
  const [filter, setFilter]             = useState<"All"|"Beginner"|"Intermediate">("All");

  async function openLesson(lesson: typeof LESSONS[0]) {
    setActiveLesson(lesson.id);
    if (lessonContent[lesson.id]) return; // Already loaded

    setLoading(lesson.id);
    try {
      // Use the chat endpoint to generate lesson content
      const res = await fetch("/api/v1/chat/suggestions", {
        headers: { Authorization: `Bearer ${localStorage.getItem("fb_token")}` }
      });
      // Actually call Claude directly via a simple chat message
      const body = { message: lesson.prompt, history: [] };
      const chatRes = await fetch("/api/v1/chat/message", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${localStorage.getItem("fb_token")}`,
        },
        body: JSON.stringify(body),
      });

      // Read SSE stream
      const reader = chatRes.body!.getReader();
      const decoder = new TextDecoder();
      let text = "";
      let buffer = "";

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop() || "";
        for (const line of lines) {
          if (!line.startsWith("data: ")) continue;
          const raw = line.slice(6).trim();
          if (raw === "[DONE]") break;
          try {
            const event = JSON.parse(raw);
            if (event.text) {
              text += event.text;
              setContent(prev => ({ ...prev, [lesson.id]: text }));
            }
          } catch {}
        }
      }
    } finally { setLoading(null); }
  }

  const filtered = filter === "All" ? LESSONS : LESSONS.filter(l => l.difficulty === filter);
  const active   = LESSONS.find(l => l.id === activeLesson);

  return (
    <AppLayout>
      <div className="mb-6">
        <h1 className="text-3xl font-extrabold text-gray-900">Learn</h1>
        <p className="text-gray-500 text-sm mt-1">Financial education, explained in plain language.</p>
      </div>

      <div className="flex gap-2 mb-6">
        {(["All","Beginner","Intermediate"] as const).map(f => (
          <button key={f} onClick={() => setFilter(f)}
            className={`px-4 py-1.5 rounded-full text-sm font-semibold border transition-colors
              ${filter === f ? "bg-blue-600 text-white border-blue-600" : "bg-white text-gray-600 border-gray-200 hover:border-gray-300"}`}>
            {f}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">

        {/* Lesson list */}
        <div className="space-y-3">
          {filtered.map(lesson => (
            <button key={lesson.id} onClick={() => openLesson(lesson)}
              className={`w-full text-left p-4 rounded-2xl border transition-all
                ${activeLesson === lesson.id
                  ? "border-blue-500 bg-blue-50 shadow-sm"
                  : "border-gray-100 bg-white hover:border-gray-200 shadow-sm"}`}>
              <div className="flex items-start gap-3">
                <span className="text-2xl">{lesson.emoji}</span>
                <div className="flex-1 min-w-0">
                  <p className="font-bold text-gray-900 text-sm">{lesson.title}</p>
                  <p className="text-xs text-gray-400 mt-0.5 leading-snug">{lesson.tagline}</p>
                  <div className="mt-2">
                    <Badge
                      label={lesson.difficulty}
                      variant={lesson.difficulty === "Beginner" ? "green" : "amber"}
                    />
                    {lessonContent[lesson.id] && (
                      <span className="ml-2 text-xs text-blue-500 font-semibold">✓ Read</span>
                    )}
                  </div>
                </div>
              </div>
            </button>
          ))}
        </div>

        {/* Lesson content */}
        <div className="lg:col-span-2">
          {!activeLesson && (
            <div className="h-full flex flex-col items-center justify-center text-center p-12 bg-white rounded-2xl border border-gray-100 shadow-sm">
              <span className="text-5xl mb-4">📚</span>
              <h3 className="font-bold text-gray-900 text-lg mb-2">Pick a lesson to start learning</h3>
              <p className="text-gray-400 text-sm">Your buddy will explain each topic in plain language, tailored to your knowledge level.</p>
            </div>
          )}

          {active && (
            <Card>
              <div className="flex items-center gap-3 mb-4">
                <span className="text-3xl">{active.emoji}</span>
                <div>
                  <h2 className="font-extrabold text-gray-900 text-xl">{active.title}</h2>
                  <Badge label={active.difficulty} variant={active.difficulty === "Beginner" ? "green" : "amber"} />
                </div>
              </div>

              {loading === active.id ? (
                <div className="flex flex-col items-center justify-center py-12 gap-3">
                  <Spinner size="lg" />
                  <p className="text-sm text-gray-400">Your buddy is preparing this lesson...</p>
                </div>
              ) : lessonContent[active.id] ? (
                <div className="prose prose-sm max-w-none">
                  <p className="text-gray-700 leading-relaxed whitespace-pre-wrap text-sm">
                    {lessonContent[active.id]}
                  </p>
                </div>
              ) : (
                <div className="flex flex-col items-center justify-center py-8 gap-3">
                  <p className="text-gray-500 text-sm">Ready to learn about {active.title}?</p>
                  <Button onClick={() => openLesson(active)}>Start Lesson</Button>
                </div>
              )}

              {lessonContent[active.id] && (
                <div className="mt-6 pt-4 border-t border-gray-100">
                  <p className="text-xs text-gray-400 mb-3">Want to explore this further?</p>
                  <Button variant="ghost" size="sm" onClick={() => {
                    const chatStore = (window as any).__chatStore;
                    document.querySelector<HTMLButtonElement>('[data-chat-open]')?.click();
                  }}>
                    💬 Ask your buddy a follow-up question
                  </Button>
                </div>
              )}
            </Card>
          )}
        </div>
      </div>

      <ChatWidget />
    </AppLayout>
  );
}
