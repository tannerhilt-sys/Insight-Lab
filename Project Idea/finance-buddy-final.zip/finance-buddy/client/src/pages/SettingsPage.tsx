// pages/SettingsPage.tsx
import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { useAuthStore } from "../stores/authStore";
import { useProfileStore } from "../stores/profileStore";
import { Card, Button, Alert, Badge } from "../components/ui";
import AppLayout from "../components/layout/AppLayout";
import ChatWidget from "../components/ai/ChatWidget";

const RISK_NAMES = ["", "Very Conservative", "Conservative", "Balanced", "Growth-Focused", "Aggressive"];

export default function SettingsPage() {
  const logout        = useAuthStore(s => s.logout);
  const { profile, fetchProfile } = useProfileStore();
  const [message, setMessage]     = useState("");
  const navigate                  = useNavigate();

  useEffect(() => { fetchProfile(); }, []);

  function handleLogout() {
    logout();
    navigate("/login");
  }

  function handleReOnboard() {
    navigate("/onboarding");
  }

  return (
    <AppLayout>
      <div className="mb-6">
        <h1 className="text-3xl font-extrabold text-gray-900">Settings</h1>
        <p className="text-gray-500 text-sm mt-1">Manage your account and Finance Buddy profile.</p>
      </div>

      <div className="max-w-2xl space-y-6">

        {/* Profile summary */}
        {profile && (
          <Card>
            <h2 className="font-bold text-gray-900 mb-4">Your Financial Profile</h2>
            <div className="space-y-3">
              <div className="flex justify-between items-center py-2 border-b border-gray-50">
                <span className="text-sm text-gray-500">Buddy Name</span>
                <span className="text-sm font-semibold text-gray-900">{profile.buddyName}</span>
              </div>
              <div className="flex justify-between items-center py-2 border-b border-gray-50">
                <span className="text-sm text-gray-500">Risk Score</span>
                <div className="flex items-center gap-2">
                  <span className="text-sm font-semibold text-gray-900">{profile.riskScore}/5</span>
                  <Badge label={RISK_NAMES[profile.riskScore]} variant="blue" />
                </div>
              </div>
              <div className="flex justify-between items-center py-2 border-b border-gray-50">
                <span className="text-sm text-gray-500">Knowledge Level</span>
                <Badge label={profile.knowledgeLevel} variant="green" />
              </div>
              <div className="flex justify-between items-start py-2 border-b border-gray-50">
                <span className="text-sm text-gray-500">Goals</span>
                <div className="flex flex-wrap gap-1 justify-end max-w-xs">
                  {profile.goals.map(g => (
                    <span key={g} className="text-xs bg-blue-50 text-blue-600 px-2 py-0.5 rounded-full">
                      {g.replace(/_/g, " ")}
                    </span>
                  ))}
                </div>
              </div>
              <div className="flex justify-between items-center py-2">
                <span className="text-sm text-gray-500">Investing Interest</span>
                <Badge
                  label={profile.investingInterest ? "Yes" : "No"}
                  variant={profile.investingInterest ? "green" : "gray"}
                />
              </div>
            </div>
            <div className="mt-5 pt-4 border-t border-gray-100">
              <p className="text-sm text-gray-500 mb-3">
                Want to update your goals or risk tolerance? Re-take the onboarding quiz — it only takes 2 minutes.
              </p>
              <Button variant="secondary" onClick={handleReOnboard}>
                Update my profile
              </Button>
            </div>
          </Card>
        )}

        {/* AI Profile Summary */}
        {profile?.profileSummary && (
          <Card>
            <h2 className="font-bold text-gray-900 mb-3">
              🤖 {profile.buddyName}'s Assessment of You
            </h2>
            <p className="text-sm text-gray-600 leading-relaxed whitespace-pre-wrap">
              {profile.profileSummary}
            </p>
          </Card>
        )}

        {/* Disclaimer */}
        <Card>
          <h2 className="font-bold text-gray-900 mb-3">📋 Important Disclaimer</h2>
          <div className="space-y-2 text-sm text-gray-600 leading-relaxed">
            <p>
              Finance Buddy is an <strong>educational tool</strong>, not a licensed financial advisor.
              All content, recommendations, and insights are for learning purposes only.
            </p>
            <p>
              Paper trading simulations use real market prices but involve <strong>no real money</strong>.
              Never make real investment decisions based solely on Finance Buddy's suggestions.
            </p>
            <p>
              Always consult a qualified financial advisor before making real investment or financial decisions.
            </p>
          </div>
        </Card>

        {/* Danger zone */}
        <Card>
          <h2 className="font-bold text-gray-900 mb-1">Account</h2>
          <p className="text-sm text-gray-400 mb-4">
            Signing out will end your current session. Your data will be saved.
          </p>
          {message && <div className="mb-3"><Alert message={message} type="success" /></div>}
          <Button variant="danger" onClick={handleLogout}>
            Sign Out
          </Button>
        </Card>

      </div>

      <ChatWidget />
    </AppLayout>
  );
}
