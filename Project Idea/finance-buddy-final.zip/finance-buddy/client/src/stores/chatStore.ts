// stores/chatStore.ts
import { create } from "zustand";
import { streamChat, api } from "../lib/api";

export interface Message {
  role:      "user" | "assistant";
  content:   string;
  streaming?: boolean;
}

interface ChatState {
  messages:    Message[];
  suggestions: string[];
  isOpen:      boolean;
  isStreaming: boolean;
  openChat:    () => void;
  closeChat:   () => void;
  sendMessage: (text: string) => Promise<void>;
  loadSuggestions: () => Promise<void>;
  clearHistory: () => void;
}

export const useChatStore = create<ChatState>((set, get) => ({
  messages:    [],
  suggestions: [],
  isOpen:      false,
  isStreaming: false,

  openChat:  () => set({ isOpen: true }),
  closeChat: () => set({ isOpen: false }),
  clearHistory: () => set({ messages: [] }),

  loadSuggestions: async () => {
    try {
      const res = await api.get<{ suggestions: string[] }>("/chat/suggestions");
      set({ suggestions: res.suggestions });
    } catch {
      set({ suggestions: ["What is an ETF?", "How do I build a budget?", "Explain my portfolio", "What should I save each month?"] });
    }
  },

  sendMessage: async (text) => {
    const { messages } = get();

    // Append user message immediately
    const userMsg: Message = { role: "user", content: text };
    const assistantMsg: Message = { role: "assistant", content: "", streaming: true };
    set({ messages: [...messages, userMsg, assistantMsg], isStreaming: true });

    // Build history (exclude the streaming placeholder)
    const history = [...messages, userMsg].map(m => ({ role: m.role, content: m.content }));

    try {
      await streamChat(
        text,
        history,
        (token) => {
          // Append each token to the last message
          set(state => {
            const msgs  = [...state.messages];
            const last  = { ...msgs[msgs.length - 1] };
            last.content += token;
            msgs[msgs.length - 1] = last;
            return { messages: msgs };
          });
        },
        () => {
          // Mark streaming done
          set(state => {
            const msgs = [...state.messages];
            const last = { ...msgs[msgs.length - 1] };
            last.streaming = false;
            msgs[msgs.length - 1] = last;
            return { messages: msgs, isStreaming: false };
          });
        }
      );
    } catch {
      set(state => {
        const msgs = [...state.messages];
        msgs[msgs.length - 1] = { role: "assistant", content: "Sorry, I had trouble connecting. Please try again." };
        return { messages: msgs, isStreaming: false };
      });
    }
  },
}));
