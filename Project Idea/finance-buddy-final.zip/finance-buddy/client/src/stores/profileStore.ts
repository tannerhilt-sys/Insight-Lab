// stores/profileStore.ts
import { create } from "zustand";
import { api } from "../lib/api";
import type { UserProfile } from "../types";

interface ProfileState {
  profile:    UserProfile | null;
  loading:    boolean;
  hasProfile: boolean;

  fetchProfile:  () => Promise<void>;
  clearProfile:  () => void;
}

export const useProfileStore = create<ProfileState>((set) => ({
  profile:    null,
  loading:    false,
  hasProfile: false,

  fetchProfile: async () => {
    set({ loading: true });
    try {
      const res = await api.get<{ profile: UserProfile }>("/onboarding/profile");
      set({ profile: res.profile, hasProfile: true });
    } catch {
      set({ hasProfile: false });
    } finally {
      set({ loading: false });
    }
  },

  clearProfile: () => set({ profile: null, hasProfile: false }),
}));
