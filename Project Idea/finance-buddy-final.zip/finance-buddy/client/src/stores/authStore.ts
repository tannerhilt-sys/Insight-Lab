// stores/authStore.ts
import { create } from "zustand";
import { api } from "../lib/api";

interface AuthState {
  token:    string | null;
  userId:   string | null;
  isAuthed: boolean;
  login:    (email: string, password: string) => Promise<void>;
  signup:   (email: string, password: string, ageConfirmed: boolean) => Promise<void>;
  logout:   () => void;
  hydrate:  () => void;
}

export const useAuthStore = create<AuthState>((set) => ({
  token:    null,
  userId:   null,
  isAuthed: false,

  hydrate: () => {
    const token  = localStorage.getItem("fb_token");
    const userId = localStorage.getItem("fb_userId");
    if (token && userId) set({ token, userId, isAuthed: true });
  },

  login: async (email, password) => {
    const res = await api.post<{ token: string; userId: string }>("/auth/login", { email, password });
    localStorage.setItem("fb_token",  res.token);
    localStorage.setItem("fb_userId", res.userId);
    set({ token: res.token, userId: res.userId, isAuthed: true });
  },

  signup: async (email, password, ageConfirmed) => {
    const res = await api.post<{ token: string; userId: string }>("/auth/signup", { email, password, ageConfirmed });
    localStorage.setItem("fb_token",  res.token);
    localStorage.setItem("fb_userId", res.userId);
    set({ token: res.token, userId: res.userId, isAuthed: true });
  },

  logout: () => {
    localStorage.removeItem("fb_token");
    localStorage.removeItem("fb_userId");
    set({ token: null, userId: null, isAuthed: false });
  },
}));
