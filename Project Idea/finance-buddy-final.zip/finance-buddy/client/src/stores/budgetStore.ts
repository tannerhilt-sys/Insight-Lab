// stores/budgetStore.ts
import { create } from "zustand";
import { api } from "../lib/api";
import type { BudgetEntry, BudgetTotals, SavingsGoal, EntryType, Category } from "../types";

interface NewEntry {
  type:         EntryType;
  amount:       number;
  category:     Category;
  description?: string;
  date:         string;
}

interface BudgetState {
  entries:      BudgetEntry[];
  totals:       BudgetTotals | null;
  goals:        SavingsGoal[];
  insight:      string;
  healthScore:  number;
  loading:      boolean;
  insightLoading: boolean;
  error:        string;

  fetchEntries:  (month?: string) => Promise<void>;
  addEntry:      (entry: NewEntry) => Promise<void>;
  deleteEntry:   (id: string) => Promise<void>;
  fetchInsight:  () => Promise<void>;
  fetchGoals:    () => Promise<void>;
  addGoal:       (label: string, targetAmount: number, deadline?: string) => Promise<void>;
}

const currentMonth = () => new Date().toISOString().slice(0, 7);

export const useBudgetStore = create<BudgetState>((set, get) => ({
  entries:        [],
  totals:         null,
  goals:          [],
  insight:        "",
  healthScore:    0,
  loading:        false,
  insightLoading: false,
  error:          "",

  fetchEntries: async (month = currentMonth()) => {
    set({ loading: true, error: "" });
    try {
      const res = await api.get<{ entries: BudgetEntry[]; totals: BudgetTotals }>(
        `/budget/entries?month=${month}`
      );
      set({ entries: res.entries, totals: res.totals, healthScore: res.totals.healthScore });
    } catch (e: any) {
      set({ error: e.message });
    } finally {
      set({ loading: false });
    }
  },

  addEntry: async (entry) => {
    await api.post("/budget/entries", entry);
    await get().fetchEntries();
  },

  deleteEntry: async (id) => {
    await api.delete(`/budget/entries/${id}`);
    await get().fetchEntries();
  },

  fetchInsight: async () => {
    set({ insightLoading: true });
    try {
      const res = await api.get<{ insight: string; healthScore: number }>("/budget/insight");
      set({ insight: res.insight, healthScore: res.healthScore });
    } finally {
      set({ insightLoading: false });
    }
  },

  fetchGoals: async () => {
    const res = await api.get<{ goals: SavingsGoal[] }>("/budget/goals");
    set({ goals: res.goals });
  },

  addGoal: async (label, targetAmount, deadline) => {
    await api.post("/budget/goals", { label, targetAmount, deadline });
    await get().fetchGoals();
  },
}));
