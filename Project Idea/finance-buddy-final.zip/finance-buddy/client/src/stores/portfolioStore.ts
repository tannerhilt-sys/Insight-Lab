// stores/portfolioStore.ts
import { create } from "zustand";
import { api } from "../lib/api";
import type { Holding, InsightCard, SearchResult } from "../types";

interface PortfolioState {
  holdings:       Holding[];
  watchlist:      Holding[];
  totalValue:     number;
  totalGainLoss:  number;
  insights:       InsightCard[];
  explanation:    { ticker: string; text: string } | null;
  loading:        boolean;
  explainLoading: boolean;
  error:          string;

  fetchHoldings:       () => Promise<void>;
  fetchWatchlist:      () => Promise<void>;
  fetchInsights:       () => Promise<void>;
  simulateBuy:         (ticker: string, shares: number) => Promise<void>;
  simulateSell:        (ticker: string, shares: number) => Promise<void>;
  addToWatchlist:      (ticker: string) => Promise<void>;
  removeFromWatchlist: (ticker: string) => Promise<void>;
  explainStock:        (ticker: string) => Promise<void>;
  searchStocks:        (query: string) => Promise<SearchResult[]>;
  generateInsight:     () => Promise<void>;
  acceptInsight:       (id: string) => Promise<void>;
  dismissInsight:      (id: string) => Promise<void>;
}

export const usePortfolioStore = create<PortfolioState>((set, get) => ({
  holdings:       [],
  watchlist:      [],
  totalValue:     0,
  totalGainLoss:  0,
  insights:       [],
  explanation:    null,
  loading:        false,
  explainLoading: false,
  error:          "",

  fetchHoldings: async () => {
    set({ loading: true });
    try {
      const res = await api.get<{ holdings: Holding[]; totalValue: number; totalGainLoss: number }>(
        "/portfolio/holdings"
      );
      set({ holdings: res.holdings, totalValue: res.totalValue, totalGainLoss: res.totalGainLoss });
    } catch (e: any) {
      set({ error: e.message });
    } finally {
      set({ loading: false });
    }
  },

  fetchWatchlist: async () => {
    const res = await api.get<{ watchlist: Holding[] }>("/portfolio/watchlist");
    set({ watchlist: res.watchlist });
  },

  fetchInsights: async () => {
    const res = await api.get<{ cards: InsightCard[] }>("/insights");
    set({ insights: (res.cards || []).filter(c => c.status === "PENDING") });
  },

  simulateBuy: async (ticker, shares) => {
    await api.post("/portfolio/buy", { ticker, shares });
    await get().fetchHoldings();
  },

  simulateSell: async (ticker, shares) => {
    await api.post("/portfolio/sell", { ticker, shares });
    await get().fetchHoldings();
  },

  addToWatchlist: async (ticker) => {
    await api.post("/portfolio/watchlist", { ticker });
    await get().fetchWatchlist();
  },

  removeFromWatchlist: async (ticker) => {
    await api.delete(`/portfolio/watchlist/${ticker}`);
    await get().fetchWatchlist();
  },

  explainStock: async (ticker) => {
    set({ explainLoading: true, explanation: null });
    try {
      const res = await api.get<{ explanation: string }>(`/portfolio/explain/${ticker}`);
      set({ explanation: { ticker, text: res.explanation } });
    } finally {
      set({ explainLoading: false });
    }
  },

  searchStocks: async (query) => {
    const res = await api.get<{ results: SearchResult[] }>(`/market/search?q=${encodeURIComponent(query)}`);
    return res.results;
  },

  generateInsight: async () => {
    await api.post("/insights/generate", {});
    await get().fetchInsights();
  },

  acceptInsight: async (id) => {
    await api.post(`/insights/${id}/accept`, {});
    await get().fetchInsights();
  },

  dismissInsight: async (id) => {
    await api.post(`/insights/${id}/dismiss`, {});
    await get().fetchInsights();
  },
}));
