// src/main.tsx
import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { useAuthStore } from "./stores/authStore";

import LoginPage      from "./pages/LoginPage";
import SignupPage     from "./pages/SignupPage";
import OnboardingPage from "./pages/OnboardingPage";
import DashboardPage  from "./pages/DashboardPage";
import BudgetPage     from "./pages/BudgetPage";
import PortfolioPage  from "./pages/PortfolioPage";
import LearnPage      from "./pages/LearnPage";
import SettingsPage   from "./pages/SettingsPage";

import "./index.css";

// ── Protected route wrapper ──────────────────────────────────────
function Protected({ children }: { children: React.ReactNode }) {
  const isAuthed = useAuthStore(s => s.isAuthed);
  if (!isAuthed) return <Navigate to="/login" replace />;
  return <>{children}</>;
}

function App() {
  const hydrate = useAuthStore(s => s.hydrate);
  React.useEffect(() => { hydrate(); }, [hydrate]);

  return (
    <BrowserRouter>
      <Routes>
        {/* Public */}
        <Route path="/login"  element={<LoginPage />} />
        <Route path="/signup" element={<SignupPage />} />

        {/* Protected */}
        <Route path="/onboarding" element={<Protected><OnboardingPage /></Protected>} />
        <Route path="/dashboard"  element={<Protected><DashboardPage /></Protected>} />
        <Route path="/budget"     element={<Protected><BudgetPage /></Protected>} />
        <Route path="/portfolio"  element={<Protected><PortfolioPage /></Protected>} />
        <Route path="/learn"      element={<Protected><LearnPage /></Protected>} />
        <Route path="/settings"   element={<Protected><SettingsPage /></Protected>} />

        {/* Default redirect */}
        <Route path="/"  element={<Navigate to="/dashboard" replace />} />
        <Route path="*"  element={<Navigate to="/dashboard" replace />} />
      </Routes>
    </BrowserRouter>
  );
}

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
