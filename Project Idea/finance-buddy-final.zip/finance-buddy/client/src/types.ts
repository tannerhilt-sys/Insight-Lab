// src/types.ts
// Shared TypeScript interfaces matching the Prisma schema and API responses

// ── Enums ─────────────────────────────────────────────────────────

export type KnowledgeLevel = "BEGINNER" | "INTERMEDIATE" | "ADVANCED";
export type SavingsHabit   = "NONE" | "OCCASIONAL" | "REGULAR" | "DISCIPLINED";
export type EntryType      = "INCOME" | "EXPENSE";
export type Category       = "HOUSING" | "FOOD" | "TRANSPORT" | "ENTERTAINMENT" | "SAVINGS" | "OTHER";
export type InsightType    = "BUDGET" | "PORTFOLIO" | "RECOMMENDATION" | "MARKET";
export type RiskLabel      = "LOW" | "MEDIUM" | "HIGH";
export type InsightStatus  = "PENDING" | "ACCEPTED" | "DISMISSED";

// ── Domain models ─────────────────────────────────────────────────

export interface User {
  id:           string;
  email:        string;
  ageConfirmed: boolean;
  createdAt:    string;
}

export interface UserProfile {
  id:                string;
  userId:            string;
  buddyName:         string;
  goals:             string[];
  knowledgeLevel:    KnowledgeLevel;
  riskScore:         number; // 1–5
  savingsHabit:      SavingsHabit;
  investingInterest: boolean;
  profileSummary:    string;
  updatedAt:         string;
}

export interface BudgetEntry {
  id:          string;
  userId:      string;
  type:        EntryType;
  amount:      number;
  category:    Category;
  description: string | null;
  date:        string;
  createdAt:   string;
}

export interface SavingsGoal {
  id:            string;
  userId:        string;
  label:         string;
  targetAmount:  number;
  currentAmount: number;
  deadline:      string | null;
  createdAt:     string;
}

export interface Holding {
  id:            string;
  userId:        string;
  ticker:        string;
  companyName:   string;
  shares:        number;
  avgCost:       number;
  purchasedAt:   string;
  // Enriched by live market data
  currentPrice?:    number;
  change?:          number;
  changePercent?:   string;
  currentValue?:    number;
  gainLoss?:        number;
  gainLossPercent?: string;
  stale?:           boolean;
}

export interface InsightCard {
  id:          string;
  userId:      string;
  type:        InsightType;
  title:       string;
  body:        string;
  riskLabel:   RiskLabel | null;
  actionLabel: string | null;
  status:      InsightStatus;
  createdAt:   string;
}

// ── API response shapes ───────────────────────────────────────────

export interface AuthResponse {
  token:  string;
  userId: string;
}

export interface BudgetTotals {
  income:      number;
  expenses:    number;
  balance:     number;
  byCategory:  Record<Category, number>;
  healthScore: number;
}

export interface BudgetEntriesResponse {
  entries: BudgetEntry[];
  totals:  BudgetTotals;
}

export interface PortfolioResponse {
  holdings:       Holding[];
  totalValue:     number;
  totalGainLoss:  number;
}

export interface WatchlistResponse {
  watchlist: Holding[];
}

export interface MarketQuote {
  ticker:        string;
  price:         number;
  change:        number;
  changePercent: string;
  volume:        number;
  lastUpdated:   string;
}

export interface SearchResult {
  ticker:   string;
  name:     string;
  type:     string;
  region:   string;
  currency: string;
}

export interface NewsArticle {
  title:     string;
  url:       string;
  source:    string;
  summary:   string;
  sentiment: string;
  published: string;
}

export interface ChatMessage {
  role:       "user" | "assistant";
  content:    string;
  streaming?: boolean;
}
