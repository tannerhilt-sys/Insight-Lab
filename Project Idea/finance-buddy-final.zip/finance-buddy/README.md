# Finance Buddy 💰

An AI-first personal finance companion for beginners.

## Quick Start

### Prerequisites
- Node.js 18+
- PostgreSQL 15+
- Anthropic API key (console.anthropic.com)
- Alpha Vantage API key (alphavantage.co)

### 1. Install dependencies
```bash
cd server && npm install
cd ../client && npm install
```

### 2. Configure environment
```bash
cd server
cp .env.example .env
# Edit .env and fill in your API keys and database URL
```

### 3. Set up the database
```bash
cd server
npm run db:generate    # Generate Prisma client
npm run db:migrate     # Run migrations (creates all tables)
npm run db:seed        # Optional: add demo data
```

### 4. Start both servers
```bash
# Terminal 1 — Backend
cd server && npm run dev

# Terminal 2 — Frontend
cd client && npm run dev
```

App runs at http://localhost:5173
API runs at http://localhost:3001
Health check: http://localhost:3001/health

### Demo login (after seeding)
- Email: demo@financebuddy.dev
- Password: password123

## Project Structure
```
finance-buddy/
├── server/
│   ├── src/
│   │   ├── index.js          # Express entry point
│   │   ├── lib/
│   │   │   ├── claude.js     # Anthropic API helper
│   │   │   ├── db.js         # Prisma client singleton
│   │   │   └── market.js     # Alpha Vantage helper
│   │   ├── middleware/
│   │   │   ├── authenticate.js
│   │   │   └── errorHandler.js
│   │   ├── prisma/
│   │   │   ├── schema.prisma
│   │   │   └── seed.js
│   │   └── routes/
│   │       ├── auth.js
│   │       ├── budget.js
│   │       ├── chat.js
│   │       ├── insights.js
│   │       ├── market.js
│   │       ├── onboarding.js
│   │       └── portfolio.js
│   └── package.json
└── client/
    ├── src/
    │   ├── lib/api.ts         # API client + streaming helper
    │   ├── stores/
    │   │   ├── authStore.ts
    │   │   └── chatStore.ts
    │   ├── pages/             # One file per screen
    │   └── main.tsx           # Router + app entry
    └── package.json
```

## Tech Stack
- **Frontend**: React 18, TypeScript, Vite, Tailwind CSS, Zustand
- **Backend**: Node.js, Express 5, Prisma ORM
- **Database**: PostgreSQL
- **AI**: Anthropic Claude API (claude-sonnet-4-20250514)
- **Market Data**: Alpha Vantage
